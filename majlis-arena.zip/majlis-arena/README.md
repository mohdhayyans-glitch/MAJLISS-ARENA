# Majlis Arena · Yallah Games!

**Family AI Game Day: Cycle 2 (Grades 6–8)**
Five family games (Football + four of ours) for P1–P4, Team A (P1 + P2) vs Team B (P3 + P4) or solo, with AI-made cards from Google Gemini and an offline deck so it always works.

**Team:** Muhammad Maaz · Muhammad Jazal · Ilan Muhammad · Mohammad Hayyan · Steve Jiju

---

## 1. What you need
- **Node.js 22 or newer**: download it from https://nodejs.org (choose "LTS"). Check with `node --version`.
- A web browser (Chrome, Edge, Safari or Firefox).
- *(Optional)* A **Google AI Studio API key** for live AI cards: https://aistudio.google.com/apikey

## 2. Set it up (once)
1. Unzip `majlis-arena.zip` anywhere (for example on your Desktop).
2. Open a terminal **inside the unzipped folder**:
   - Windows: open the folder, click the address bar, type `cmd`, press Enter.
   - Mac: right-click the folder → *New Terminal at Folder*.
3. Install the packages:
   ```bash
   npm install
   ```

## 3. Turn on the AI (optional)
1. Copy `.env.example` and rename the copy to `.env`.
2. Open `.env` in Notepad / TextEdit and paste your key after `GEMINI_API_KEY=`:
   ```
   GEMINI_API_KEY=your-key-here
   GEMINI_TEXT_MODEL=gemini-3.5-flash
   GEMINI_IMAGE_MODEL=gemini-2.5-flash-image
   ```
3. Test it:
   ```bash
   npm run check-ai
   ```
   It lists the models your key can use and says **WORKS** or **FAILED** for text and images.

No key? Skip this step. Every game still works with the built-in **offline deck**.

## 4. Run it
```bash
npm start
```
Then open **http://localhost:3000** in your browser.
- Landing page: http://localhost:3000
- Games: http://localhost:3000/play.html

Stop the server with `Ctrl + C`.

## 5. How to play
1. **Pick a game:** World Cup Match, Market Mystery, Festival Charades, Grandma's Proverb or Story Chest Finale.
2. **Players:** type four names. Team A = P1 + P2, Team B = P3 + P4. You can add family facts (hometown, dish, sport) for personalised cards.
3. **Rules:** set the points, seconds per card, rounds, difficulty and the tie-break rule.
4. **Ready check:** every team or player taps Ready, then kick off.
5. **Play:** the AI deals a card. The host taps **Correct** or **Try Again** (shows a hint), then **Miss** if it's still wrong.
6. **Results:** round scores, sudden death if it's tied, then the champion and a passport stamp.

Host shortcuts: `C` = Correct, `T` = Try Again / Miss, `P` = pause the timer.

## 6. Troubleshooting
| Problem | Fix |
|---------|-----|
| `npm` is not recognised | Install Node.js (step 1), then open a new terminal |
| `Port 3000 is in use` | Add `PORT=3001` to `.env`, then open http://localhost:3001 |
| Chip says **OFFLINE DECK MODE** | No key in `.env`, or restart `npm start` after adding it |
| AI busy (HTTP 503) | Google is overloaded. The app retries once, then uses the offline deck |
| No AI pictures | The free Gemini tier has no image quota. Picture cards show the image prompt instead |
| 3D title doesn't show | Your browser has WebGL off. A flat title is shown instead, and everything else works |

## 7. What's inside
```
server.js            Express server + Gemini endpoints (/api/card, /api/image, /api/story-final, /api/commentary, /api/status)
data/decks.js        Offline card decks + commentary lines
public/index.html    Landing page (3D title: public/js/landing.js)
public/play.html     The game app (public/js/play.js engine, public/js/games.js the five games)
public/css/          Glass design system (base.css), landing.css, play.css
tools/check-ai.mjs   Tests your Gemini key and models
submission/          Concept, plan, status, decisions, tests, demo script, ad script
```

## Credits
three.js (MIT) · Rubik font (SIL OFL, via @fontsource) · Microsoft Fluent Emoji 3D icons (MIT) · Google Gemini API
