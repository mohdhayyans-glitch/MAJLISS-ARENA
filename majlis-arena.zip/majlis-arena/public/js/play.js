// Majlis Arena game engine: one shared flow for all five games.
// pick → players → rules → ready → turns (card · timer · Correct/Try Again) → round scores → tie-break → results
import { GAMES, gameById } from './games.js';

const app = document.getElementById('app');
const exitBtn = document.getElementById('exit-game');
const aiChip = document.getElementById('ai-status');
const toastEl = document.getElementById('toast');

const ZONES = ['MIDFIELD', 'ATTACK', 'BOX', 'GOAL'];
const MAX_TIEBREAKS = 3;

// ---------- helpers ----------
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const half = (p) => Math.ceil(p / 2);
const store = {
  get(k, d) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch { return d; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* storage blocked: fine */ } }
};

function toast(msg) {
  toastEl.textContent = msg;
  toastEl.classList.add('show');
  clearTimeout(toast.t);
  toast.t = setTimeout(() => toastEl.classList.remove('show'), 2600);
}

async function api(path, body, timeoutMs = 15000) {
  const res = await fetch(path, {
    method: body ? 'POST' : 'GET',
    headers: body ? { 'content-type': 'application/json' } : undefined,
    body: body ? JSON.stringify(body) : undefined,
    signal: AbortSignal.timeout(timeoutMs)
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

// ---------- state ----------
const saved = store.get('majlis-setup', {});
const S = {
  screen: 'pick',
  status: { aiConfigured: false, imagesConfigured: false },
  game: null,
  names: saved.names || ['', '', '', ''],
  facts: saved.facts || { hometown: '', dish: '', sport: '' },
  settings: null,
  participants: [],
  ready: {},
  scores: {},
  rounds: [],          // [{ [pid]: points }]
  round: 1,
  turn: 0,             // index into the current turn order
  order: [],           // participant ids for this round (tie-break = contenders only)
  tiebreak: 0,         // 0 = normal play, 1..3 = sudden-death round number
  tbScores: {},
  card: null,
  cardSource: null,
  cardLoading: false,
  cardError: null,
  attempt: 0,          // 0 first try, 1 after Try Again
  zone: 0,             // football: ball position this attack
  turnPoints: 0,
  revealed: false,     // festival secret / host answer
  answerShown: false,
  image: null,         // { state: 'loading'|'ok'|'fail'|'off', src }
  used: [],
  storyLines: [],
  lineDraft: '',
  commentary: '',
  timer: { left: 0, total: 0, running: false, up: false },
  results: null,
  finale: null
};

let tick = null;

// ---------- AI status ----------
api('/api/status').then((s) => {
  S.status = s;
  aiChip.textContent = s.aiConfigured ? (s.imagesConfigured ? 'GEMINI ON · TEXT + IMAGES' : 'GEMINI ON · TEXT') : 'OFFLINE DECK MODE';
  aiChip.className = 'chip ' + (s.aiConfigured ? 'chip-ai' : 'chip-offline');
  aiChip.title = s.aiConfigured ? 'Cards are written by Gemini. If it fails, the offline deck is used.' : 'No Gemini key set on the server. Cards come from the hand-checked offline deck.';
}).catch(() => {
  aiChip.textContent = 'SERVER UNREACHABLE';
  aiChip.className = 'chip chip-offline';
});

// ---------- participants ----------
function buildParticipants() {
  const players = S.names.map((n, i) => ({ id: `P${i + 1}`, name: n.trim() }));
  if (S.game.mode === 'team') {
    S.participants = [
      { id: 'A', name: 'Team A', members: [players[0], players[1]], cls: 'a' },
      { id: 'B', name: 'Team B', members: [players[2], players[3]], cls: 'b' }
    ];
  } else {
    S.participants = players.map((p, i) => ({ id: p.id, name: p.name, members: [p], cls: ['a', 'b', 'c', 'd'][i] }));
  }
}
const pById = (id) => S.participants.find((p) => p.id === id);
const current = () => pById(S.order[S.turn]);
function label(p) {
  return S.game.mode === 'team' ? `${p.name} (${p.members.map((m) => m.name).join(' + ')})` : `${p.name} · ${p.members[0].id}`;
}
// festival: actor/guesser swap each round
function roles(p) {
  const flip = (S.round + (S.tiebreak || 0)) % 2 === 0;
  return flip ? { actor: p.members[1], guesser: p.members[0] } : { actor: p.members[0], guesser: p.members[1] };
}

// ---------- screens ----------
function render() {
  exitBtn.hidden = ['pick'].includes(S.screen);
  const views = { pick: viewPick, players: viewPlayers, rules: viewRules, ready: viewReady, turn: viewTurn, round: viewRound, results: viewResults };
  app.innerHTML = views[S.screen]();
  app.dataset.screen = S.screen;
  bind();
  if (S.screen !== 'turn') window.scrollTo({ top: 0 });
}

function stepper(n) {
  const steps = ['Game', 'Players', 'Rules', 'Ready', 'Play', 'Results'];
  return `<ol class="stepper mono" aria-label="Progress">${steps.map((s, i) => `<li class="${i < n ? 'done' : i === n ? 'now' : ''}">${String(i + 1).padStart(2, '0')} ${s}</li>`).join('')}</ol>`;
}

function viewPick() {
  const passport = store.get('majlis-passport', []);
  return `
  <section class="screen">
    ${stepper(0)}
    <p class="eyebrow">STEP 01 · CHOOSE A GAME</p>
    <h1 class="gtext" data-text="Pick tonight's game.">Pick tonight's game.</h1>
    <ul class="pick-grid">
      ${GAMES.map((g, i) => `
      <li class="slab ${['', 'slab-teal', 'slab-blue', 'slab-ink', ''][i]}">
        <button class="slab-in pick-card" data-pick="${g.id}">
          <img class="icon3d pop float d${i % 4}" src="${g.icon}" alt="">
          <span class="chip ${g.mode === 'team' ? 'chip-team' : 'chip-solo'}">${g.mode === 'team' ? 'TEAM' : 'SOLO'}</span>
          <span class="pick-name">${esc(g.name)}</span>
          <span class="pick-blurb">${esc(g.blurb)}</span>
          <span class="mono pick-tag">${g.tag}</span>
        </button>
      </li>`).join('')}
    </ul>
    <div class="glass passport">
      <div><p class="eyebrow">FAMILY PASSPORT</p><p class="muted">Every finished game earns a stamp on this device.</p></div>
      <div class="stamps">
        ${GAMES.map((g) => { const s = passport.filter((p) => p.game === g.id); return `<div class="stamp ${s.length ? 'got' : ''}" title="${esc(g.name)}"><img src="${g.icon}" alt=""><span class="mono">${s.length ? `×${s.length}` : '—'}</span></div>`; }).join('')}
      </div>
    </div>
  </section>`;
}

function viewPlayers() {
  const g = S.game;
  return `
  <section class="screen narrow">
    ${stepper(1)}
    <p class="eyebrow">STEP 02 · PLAYERS</p>
    <h1 class="gtext" data-text="Who's playing?">Who's playing?</h1>
    <p class="lead">${g.mode === 'team' ? '<b>Team A</b> is P1 + P2. <b>Team B</b> is P3 + P4.' : 'Solo game: P1 to P4 each play for their own points.'}</p>
    <form id="players-form" class="glass form" novalidate>
      <div class="teams ${g.mode}">
        ${[0, 1, 2, 3].map((i) => `
          ${g.mode === 'team' && i % 2 === 0 ? `<p class="team-head mono ${i === 0 ? 'a' : 'b'}">${i === 0 ? 'TEAM A' : 'TEAM B'}</p>` : ''}
          <label class="field">
            <span class="mono">P${i + 1}</span>
            <input name="p${i}" maxlength="16" autocomplete="off" placeholder="${['Mama', 'Baba', 'Sara', 'Omar'][i]}" value="${esc(S.names[i])}" required>
          </label>`).join('')}
      </div>
      <details class="facts">
        <summary>Add family facts (optional). The AI weaves them into the cards.</summary>
        <div class="facts-grid">
          <label class="field"><span class="mono">HOMETOWN</span><input name="hometown" maxlength="40" value="${esc(S.facts.hometown)}" placeholder="e.g. Muscat"></label>
          <label class="field"><span class="mono">FAMILY DISH</span><input name="dish" maxlength="40" value="${esc(S.facts.dish)}" placeholder="e.g. Machboos"></label>
          <label class="field"><span class="mono">FAVOURITE SPORT</span><input name="sport" maxlength="40" value="${esc(S.facts.sport)}" placeholder="e.g. Football"></label>
        </div>
      </details>
      <p id="form-error" class="error" role="alert"></p>
      <div class="actions">
        <button type="button" class="btn btn-glass" data-go="pick">← Change game</button>
        <button type="submit" class="btn btn-lime">Next: rules →</button>
      </div>
    </form>
  </section>`;
}

function viewRules() {
  const g = S.game;
  const st = S.settings || { ...g.defaults, tiebreak: 'sudden', difficulty: 'medium' };
  return `
  <section class="screen narrow">
    ${stepper(2)}
    <p class="eyebrow">STEP 03 · RULES</p>
    <h1 class="gtext" data-text="Set the rules.">Set the rules.</h1>
    <div class="rules-layout">
      <form id="rules-form" class="glass form" novalidate>
        <label class="field"><span class="mono">${g.id === 'football' ? 'POINTS PER GOAL' : 'POINTS PER CORRECT ANSWER'} (1–10)</span>
          <input type="number" name="points" min="1" max="10" step="1" value="${st.points}" inputmode="numeric"></label>
        <label class="field"><span class="mono">SECONDS PER CARD (15–180)</span>
          <input type="number" name="seconds" min="15" max="180" step="5" value="${st.seconds}" inputmode="numeric"></label>
        <label class="field"><span class="mono">ROUNDS (1–5) · EVERY ${g.mode === 'team' ? 'TEAM' : 'PLAYER'} PLAYS ONCE PER ROUND</span>
          <input type="number" name="rounds" min="1" max="5" step="1" value="${st.rounds}" inputmode="numeric"></label>
        <fieldset class="field">
          <legend class="mono">DIFFICULTY</legend>
          <div class="seg">${['easy', 'medium', 'hard'].map((d) => `<label><input type="radio" name="difficulty" value="${d}" ${st.difficulty === d ? 'checked' : ''}><span>${d}</span></label>`).join('')}</div>
        </fieldset>
        <fieldset class="field">
          <legend class="mono">IF IT'S A TIE AT THE END</legend>
          <div class="seg">
            <label><input type="radio" name="tiebreak" value="sudden" ${st.tiebreak === 'sudden' ? 'checked' : ''}><span>⚡ Sudden death</span></label>
            <label><input type="radio" name="tiebreak" value="share" ${st.tiebreak === 'share' ? 'checked' : ''}><span>🤝 Share the trophy</span></label>
          </div>
        </fieldset>
        <p id="form-error" class="error" role="alert"></p>
        <div class="actions">
          <button type="button" class="btn btn-glass" data-go="players">← Players</button>
          <button type="submit" class="btn btn-lime">Next: ready check →</button>
        </div>
      </form>
      <aside class="slab slab-ink"><div class="slab-in how">
        <img class="icon3d float" src="${g.icon}" alt="">
        <p class="eyebrow lime">HOW TO PLAY · ${esc(g.name.toUpperCase())}</p>
        <ol>${g.rules.map((r) => `<li>${esc(r)}</li>`).join('')}</ol>
      </div></aside>
    </div>
  </section>`;
}

function viewReady() {
  const all = S.participants.every((p) => S.ready[p.id]);
  const st = S.settings;
  return `
  <section class="screen narrow">
    ${stepper(3)}
    <p class="eyebrow">STEP 04 · READY CHECK</p>
    <h1 class="gtext" data-text="Everyone ready?">Everyone ready?</h1>
    <p class="lead">Each ${S.game.mode === 'team' ? 'team' : 'player'} taps their card. Then the host starts the match.</p>
    <div class="ready-grid ${S.game.mode}">
      ${S.participants.map((p) => `
      <button class="ready-card glass ${p.cls} ${S.ready[p.id] ? 'on' : ''}" data-ready="${p.id}" aria-pressed="${S.ready[p.id] ? 'true' : 'false'}">
        <span class="mono">${esc(p.name)}</span>
        <b>${S.game.mode === 'team' ? p.members.map((m) => esc(m.name)).join(' + ') : esc(p.members[0].id)}</b>
        <span class="ready-state">${S.ready[p.id] ? '✓ READY' : 'TAP WHEN READY'}</span>
      </button>`).join('')}
    </div>
    <div class="glass summary mono">
      <span>${esc(S.game.name.toUpperCase())}</span>
      <span>${st.rounds} ROUND${st.rounds > 1 ? 'S' : ''}</span>
      <span>${st.points} PTS ${S.game.id === 'football' ? 'PER GOAL' : 'PER CORRECT'}</span>
      <span>${st.seconds}s PER CARD</span>
      <span>${st.difficulty.toUpperCase()}</span>
      <span>TIE: ${st.tiebreak === 'sudden' ? 'SUDDEN DEATH' : 'SHARE'}</span>
    </div>
    <div class="actions">
      <button class="btn btn-glass" data-go="rules">← Rules</button>
      <button class="btn btn-lime btn-lg" id="kickoff" ${all ? '' : 'disabled'}>${all ? 'Yallah, kick off! →' : 'Waiting for everyone…'}</button>
    </div>
  </section>`;
}

function scoreStrip() {
  return `<div class="score-strip">${S.participants.map((p) => `
    <div class="score-pill ${p.cls} ${current()?.id === p.id ? 'active' : ''} ${S.tiebreak && !S.order.includes(p.id) ? 'out' : ''}">
      <span class="mono">${esc(S.game.mode === 'team' ? p.name : p.members[0].id)}</span>
      <b>${esc(S.game.mode === 'team' ? p.members.map((m) => m.name).join(' + ') : p.name)}</b>
      <strong>${S.scores[p.id]}${S.tiebreak ? `<small> +${S.tbScores[p.id] || 0}</small>` : ''}</strong>
    </div>`).join('')}</div>`;
}

function viewTurn() {
  const g = S.game;
  const p = current();
  const t = S.timer;
  const pct = t.total ? Math.max(0, (t.left / t.total) * 100) : 100;
  const r = g.id === 'festival' ? roles(p) : null;
  const roundLabel = S.tiebreak ? `SUDDEN DEATH ${S.tiebreak}/${MAX_TIEBREAKS}` : `ROUND ${S.round} / ${S.settings.rounds}`;

  return `
  <section class="screen play-screen">
    <div class="turn-head">
      <p class="mono live"><span class="dot"></span> ${roundLabel} · ${esc(g.name.toUpperCase())}</p>
      ${scoreStrip()}
    </div>

    <div class="turn-layout">
      <div class="turn-main">
        <div class="whose ${p.cls}">
          <img class="icon3d" src="${g.icon}" alt="">
          <div>
            <p class="mono">NOW PLAYING</p>
            <h2>${esc(label(p))}</h2>
            ${r ? `<p class="roles">🎭 Actor: <b>${esc(r.actor.name)}</b> · 👀 Guesser: <b>${esc(r.guesser.name)}</b></p>` : ''}
          </div>
        </div>

        ${g.id === 'football' ? pitch() : ''}

        <div class="slab ${g.id === 'football' ? 'slab-teal' : g.id === 'proverb' ? 'slab-ink' : g.id === 'festival' ? 'slab-blue' : ''} card-slab">
          <div class="slab-in card">${cardBody()}</div>
        </div>
      </div>

      <aside class="turn-side">
        <div class="glass timer-box ${t.up ? 'up' : ''} ${t.left <= 10 && t.running ? 'low' : ''}">
          <p class="mono">TIMER</p>
          <p class="time mono" id="time">${fmt(t.left)}</p>
          <div class="tbar"><i id="tbar" style="width:${pct}%"></i></div>
          <button class="btn btn-glass btn-sm" id="pause" ${S.card && !t.up ? '' : 'disabled'}>${t.running ? '⏸ Pause' : '▶ Resume'}</button>
          ${t.up ? '<p class="timeup">⏰ Time\'s up! Host decides.</p>' : ''}
        </div>

        <div class="glass host">
          <p class="mono">HOST DECIDES</p>
          <button class="btn btn-lime btn-lg host-btn" id="correct" ${canDecide() ? '' : 'disabled'}>✓ Correct</button>
          <button class="btn btn-glass btn-lg host-btn" id="again" ${canDecide() ? '' : 'disabled'}>${S.attempt === 0 ? '↻ Try Again (show hint)' : '✗ Miss · next'}</button>
          <p class="muted small">${hostNote()}</p>
          <button class="linkish" id="newcard" ${S.card ? '' : 'disabled'}>Card not right? Deal a different one (no penalty)</button>
        </div>

        ${S.commentary ? `<div class="glass comment"><p class="mono">🎙 COMMENTARY</p><p>${esc(S.commentary)}</p></div>` : ''}
      </aside>
    </div>
  </section>`;
}

const canDecide = () => Boolean(S.card) && !(S.game.secret && !S.revealed);

function hostNote() {
  if (S.game.secret && S.card && !S.revealed) return 'The actor reveals the card first. The timer starts then.';
  const pts = S.settings.points;
  if (S.game.id === 'football') return S.attempt === 0 ? `Correct moves the ball one zone. Reach the GOAL for ${pts} pts.` : 'Second chance with the hint. Miss = saved by the keeper.';
  if (S.game.id === 'market' || S.game.id === 'proverb') return S.attempt === 0 ? `Correct now = ${pts} pts. Try Again shows a hint (then ${half(pts)} pts).` : `With hint: ${half(pts)} pts. Miss = 0 and next player.`;
  return S.attempt === 0 ? `Correct = ${pts} pts. Try Again gives one more go (same card).` : `Last chance: Correct = ${pts} pts, Miss = 0.`;
}

function pitch() {
  const p = current();
  const dir = p.id === 'B' ? 'rtl' : 'ltr';
  return `<div class="pitch-live ${dir}" aria-label="Ball is in the ${ZONES[S.zone]} zone">
    ${ZONES.map((z, i) => `<span class="pz ${i === S.zone ? 'here' : ''} ${i === 3 ? 'goal' : ''}">${z}</span>`).join('')}
    <img class="ball" src="/img/icons/soccer.png" alt="" style="--zone:${S.zone}">
  </div>`;
}

function cardBody() {
  const g = S.game;
  if (S.cardLoading) {
    return `<div class="loading"><div class="spinner"></div><p class="mono">${S.status.aiConfigured ? 'GEMINI IS WRITING YOUR CARD…' : 'DEALING FROM THE OFFLINE DECK…'}</p><div class="skel"></div><div class="skel short"></div></div>`;
  }
  if (S.cardError) {
    return `<div class="loading"><p class="error">Couldn't get a card: ${esc(S.cardError)}</p><button class="btn btn-lime" id="retry">Try again</button></div>`;
  }
  if (!S.card) return '';
  const c = S.card;
  const source = S.cardSource === 'ai' ? '<span class="chip chip-ai">✦ AI-GENERATED · GEMINI</span>' : '<span class="chip chip-offline">OFFLINE DECK</span>';
  const hint = S.attempt > 0 && c.hint ? `<p class="hint">💡 ${esc(c.hint)}</p>` : '';

  if (g.secret && !S.revealed) {
    const r = roles(current());
    return `<div class="card-top">${source}</div>
      <div class="secret-cover">
        <p class="mono">SECRET CARD</p>
        <h3>${esc(r.actor.name)}, you're the actor.</h3>
        <p>${esc(r.guesser.name)}, look away from the screen!</p>
        <button class="btn btn-violet btn-lg" id="reveal">👁 Reveal to actor</button>
      </div>`;
  }

  let body = '';
  if (g.id === 'festival') {
    body = `<p class="mono kicker">ACT OUT THIS FESTIVAL</p><p class="big">${esc(c.clue)}</p><p class="act">🎭 ${esc(c.hint)}</p>`;
  } else if (g.id === 'proverb') {
    body = `<p class="mono kicker">FINISH THE PROVERB</p><p class="big quote">"${esc(c.clue)}"</p>${hint}`;
  } else if (g.id === 'story') {
    body = `<p class="mono kicker">STORY CHEST · TELL THE NEXT LINE</p><p class="big story-clue">${esc(c.clue)}</p>${hint}
      <label class="field line"><span class="mono">TYPE YOUR STORY LINE (OPTIONAL, ADDED TO THE FINALE)</span>
      <textarea id="line" maxlength="200" rows="2" placeholder="One evening…">${esc(S.lineDraft)}</textarea></label>`;
  } else if (g.id === 'market') {
    body = `${marketImage()}<p class="mono kicker">WHICH COUNTRY IS THIS MARKET IN?</p><p class="clue">${esc(c.clue)}</p>${hint}`;
  } else {
    body = `<p class="mono kicker">FOOTBALL RIDDLE · ${ZONES[S.zone]} → ${ZONES[Math.min(S.zone + 1, 3)]}</p><p class="clue big-ish">${esc(c.clue)}</p>${hint}`;
  }

  const answer = g.hostAnswer ? `
    <div class="answer ${S.answerShown ? 'shown' : ''}">
      <button class="linkish" id="show-answer">${S.answerShown ? 'Hide answer' : '🔒 Host: show answer'}</button>
      ${S.answerShown ? `<p><b>${esc(c.answer)}</b>${c.fact ? `<br><span class="fact">${esc(c.fact)}</span>` : ''}</p>` : ''}
    </div>` : (c.fact ? `<p class="fact">Did you know? ${esc(c.fact)}</p>` : '');

  return `<div class="card-top">${source}</div>${body}${answer}`;
}

function marketImage() {
  const im = S.image;
  if (!im || im.state === 'off') {
    return `<figure class="mimg fallback"><div class="icons"><img class="icon3d float" src="/img/icons/lantern.png" alt=""><img class="icon3d float d1" src="/img/icons/basket.png" alt=""><img class="icon3d float d2" src="/img/icons/tea.png" alt=""></div>
      <figcaption class="mono">${S.card.imagePrompt ? `IMAGE PROMPT (AI images off): ${esc(S.card.imagePrompt)}` : 'PICTURE CARD · imagine the scene!'}</figcaption></figure>`;
  }
  if (im.state === 'loading') return `<figure class="mimg"><div class="spinner"></div><figcaption class="mono">AI IS PAINTING THE MARKET…</figcaption></figure>`;
  if (im.state === 'fail') {
    return `<figure class="mimg fallback"><div class="icons"><img class="icon3d" src="/img/icons/lantern.png" alt=""><img class="icon3d" src="/img/icons/basket.png" alt=""></div>
      <figcaption class="mono">IMAGE COULDN'T BE MADE · PROMPT: ${esc(S.card.imagePrompt)}</figcaption></figure>`;
  }
  return `<figure class="mimg"><img class="gen" src="${im.src}" alt="AI-generated picture of the market described below"><figcaption class="mono">✦ AI-GENERATED IMAGE · ${im.by || 'AI'}</figcaption></figure>`;
}

function viewRound() {
  const done = S.rounds.length;
  const last = S.rounds[done - 1] || {};
  const isLast = done >= S.settings.rounds;
  return `
  <section class="screen narrow">
    ${stepper(4)}
    <p class="eyebrow">ROUND ${done} COMPLETE</p>
    <h1 class="gtext" data-text="Round ${done} scores">Round ${done} scores</h1>
    ${scoreTable()}
    <div class="round-hl">${S.participants.map((p) => `<div class="glass rh ${p.cls}"><span class="mono">${esc(p.name)}</span><b>+${last[p.id] || 0}</b><small>this round</small></div>`).join('')}</div>
    <div class="actions">
      <button class="btn btn-lime btn-lg" id="next-round">${isLast ? 'See final results →' : `Start round ${done + 1} →`}</button>
    </div>
  </section>`;
}

function scoreTable() {
  const n = S.settings.rounds;
  return `<div class="slab slab-ink"><div class="slab-in"><table class="sb mono">
    <thead><tr><th>${S.game.mode === 'team' ? 'TEAM' : 'PLAYER'}</th>${Array.from({ length: n }, (_, i) => `<th>R${i + 1}</th>`).join('')}${S.tiebreak || S.results?.tb ? '<th>TB</th>' : ''}<th>TOTAL</th></tr></thead>
    <tbody>${S.participants.map((p) => `<tr class="${p.cls}"><td>${esc(S.game.mode === 'team' ? `${p.name} · ${p.members.map((m) => m.name).join(' + ')}` : p.name)}</td>
      ${Array.from({ length: n }, (_, i) => `<td>${S.rounds[i] ? S.rounds[i][p.id] || 0 : '·'}</td>`).join('')}
      ${S.tiebreak || S.results?.tb ? `<td>${S.tbScores[p.id] ?? '–'}</td>` : ''}
      <td class="tot">${S.scores[p.id]}</td></tr>`).join('')}</tbody>
  </table></div></div>`;
}

function viewResults() {
  const R = S.results;
  const ranked = [...S.participants].sort((a, b) => (S.scores[b.id] + (S.tbScores[b.id] || 0) / 100) - (S.scores[a.id] + (S.tbScores[a.id] || 0) / 100));
  const winnerNames = R.winners.map((id) => pById(id)).map((p) => (S.game.mode === 'team' ? `${p.name} (${p.members.map((m) => m.name).join(' + ')})` : p.name));
  return `
  <section class="screen">
    ${stepper(5)}
    <div class="champ">
      <img class="icon3d big float" src="/img/icons/${R.shared ? 'trophy' : 'crown'}.png" alt="">
      <p class="eyebrow">${R.shared ? 'SHARED TROPHY' : 'CHAMPION'} · ${esc(S.game.name.toUpperCase())}</p>
      <h1 class="gtext mega-ish" data-text="${esc(winnerNames.join(' & '))}">${esc(winnerNames.join(' & '))}</h1>
      <p class="lead">${R.shared ? (R.reason === 'share' ? 'Level on points. As agreed, the trophy is shared!' : `Still level after ${MAX_TIEBREAKS} sudden-death rounds. The trophy is shared!`) : (R.tb ? 'Decided in sudden death!' : 'What a game night. Mabrook!')}</p>
    </div>
    <ol class="ranking">${ranked.map((p, i) => `<li class="glass ${p.cls} ${R.winners.includes(p.id) ? 'win' : ''}"><span class="mono">#${i + 1}</span><b>${esc(S.game.mode === 'team' ? `${p.name} · ${p.members.map((m) => m.name).join(' + ')}` : p.name)}</b><strong>${S.scores[p.id]}<small> pts${R.tb ? ` · TB ${S.tbScores[p.id] || 0}` : ''}</small></strong></li>`).join('')}</ol>
    <h2 class="sub">Round by round</h2>
    ${scoreTable()}
    ${S.game.story ? finaleBlock() : ''}
    <div class="actions center">
      <button class="btn btn-lime btn-lg" id="again-same">Play again (same players)</button>
      <button class="btn btn-violet btn-lg" id="other-game">Choose another game</button>
      <a class="btn btn-glass btn-lg" href="/">Home</a>
    </div>
  </section>`;
}

function finaleBlock() {
  const f = S.finale;
  if (!f) return `<div class="glass finale-cta"><img class="icon3d" src="/img/icons/newspaper.png" alt=""><div><h2>Print the family story</h2><p>${S.storyLines.length} story line${S.storyLines.length === 1 ? '' : 's'} saved. The AI turns them into tonight's front page.</p></div><button class="btn btn-ink btn-lg" id="make-story">📰 Write our front page</button></div>`;
  if (f.loading) return `<div class="glass finale-cta"><div class="spinner"></div><p class="mono">${S.status.aiConfigured ? 'GEMINI IS WRITING TONIGHT\'S STORY…' : 'PRINTING FROM THE OFFLINE PRESS…'}</p></div>`;
  return `<article class="paper">
    <p class="paper-mast">THE MAJLIS TIMES</p>
    <p class="paper-date mono">${new Date().toLocaleDateString([], { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }).toUpperCase()} · ${f.source === 'ai' ? '✦ WRITTEN BY GEMINI' : 'OFFLINE EDITION (TEMPLATE)'}</p>
    <h2 class="paper-head">${esc(f.headline)}</h2>
    <div class="paper-cols">
      <figure class="paper-img">${f.img?.state === 'ok' ? `<img src="${f.img.src}" alt="AI-generated front-page picture">` : f.img?.state === 'loading' ? '<div class="spinner"></div>' : '<img class="icon3d" src="/img/icons/trophy.png" alt="">'}
        <figcaption class="mono">${f.img?.state === 'ok' ? `✦ AI-GENERATED IMAGE · ${f.img.by || 'AI'}` : f.img?.state === 'loading' ? 'PAINTING…' : f.imagePrompt ? 'IMAGE PROMPT: ' + esc(f.imagePrompt) : ''}</figcaption></figure>
      <p class="paper-story">${esc(f.story)}</p>
    </div>
  </article>`;
}

function fmt(s) {
  s = Math.max(0, Math.ceil(s));
  return `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;
}

// ---------- flow ----------
function go(screen) { stopTimer(); S.screen = screen; render(); }

function startGame() {
  S.scores = Object.fromEntries(S.participants.map((p) => [p.id, 0]));
  S.tbScores = {};
  S.rounds = [];
  S.round = 1;
  S.tiebreak = 0;
  S.storyLines = [];
  S.results = null;
  S.finale = null;
  S.used = [];
  startRound();
}

function startRound() {
  S.order = S.participants.map((p) => p.id);
  S.turn = 0;
  if (!S.tiebreak) S.rounds.push(Object.fromEntries(S.participants.map((p) => [p.id, 0])));
  startTurn();
}

function startTurn() {
  S.zone = 0;
  S.turnPoints = 0;
  S.commentary = '';
  S.lineDraft = '';
  S.screen = 'turn';
  dealCard();
}

async function dealCard() {
  stopTimer();
  S.card = null;
  S.cardError = null;
  S.cardLoading = true;
  S.attempt = 0;
  S.revealed = false;
  S.answerShown = false;
  S.image = null;
  render();
  try {
    const data = await api('/api/card', { game: S.game.id, difficulty: S.settings.difficulty, used: S.used, familyFacts: S.facts });
    S.card = data.card;
    S.cardSource = data.source;
    S.used.push(data.card.answer);
    S.cardLoading = false;
    if (S.game.image) loadImage();
    // festival: timer starts once the actor reveals the card
    if (!S.game.secret) startTimer();
    render();
  } catch (err) {
    S.cardLoading = false;
    S.cardError = err.name === 'TimeoutError' ? 'the server took too long' : 'the server is not reachable';
    render();
  }
}

// Gemini image (only if the key allows it). Returns { state, src, by }.
async function makeImage(prompt) {
  try {
    const r = await api('/api/image', { prompt }, 40000);
    if (r.ok) return { state: 'ok', src: r.src, by: 'GEMINI' };
    if (r.reason === 'quota' || r.reason === 'failed') imagesOff(r.reason);
  } catch { /* fall back to the icon card */ }
  return { state: 'fail' };
}

async function loadImage() {
  const prompt = S.card.imagePrompt;
  if (!prompt || !S.status.imagesConfigured) { S.image = { state: 'off' }; return; }
  const card = S.card;
  S.image = { state: 'loading' };
  const result = await makeImage(prompt);
  if (S.card !== card) return; // card changed while painting
  S.image = result;
  if (S.screen === 'turn') renderKeepScroll();
}

// Image generation refused (e.g. free-tier quota): stop asking and say so in the status chip.
async function imagesOff(reason) {
  try {
    const s = await api('/api/status', null, 4000);
    if (s.imagesConfigured && reason !== 'quota') return; // one-off failure: keep trying
  } catch { /* keep going */ }
  S.status.imagesConfigured = false;
  aiChip.textContent = 'GEMINI ON · TEXT';
  aiChip.title = 'Gemini refused image requests (quota). Picture cards show the labeled image prompt instead.';
}

function renderKeepScroll() {
  const draft = document.getElementById('line')?.value;
  if (draft !== undefined) S.lineDraft = draft;
  const y = window.scrollY;
  render();
  window.scrollTo({ top: y });
}

function startTimer() {
  stopTimer();
  S.timer = { left: S.settings.seconds, total: S.settings.seconds, running: true, up: false };
  runTimer();
}
function runTimer() {
  clearInterval(tick);
  let last = performance.now();
  tick = setInterval(() => {
    const now = performance.now();
    S.timer.left -= (now - last) / 1000;
    last = now;
    if (S.timer.left <= 0) {
      S.timer.left = 0;
      S.timer.running = false;
      S.timer.up = true;
      clearInterval(tick);
      renderKeepScroll();
      return;
    }
    const t = document.getElementById('time');
    const b = document.getElementById('tbar');
    if (t) t.textContent = fmt(S.timer.left);
    if (b) b.style.width = `${(S.timer.left / S.timer.total) * 100}%`;
    document.querySelector('.timer-box')?.classList.toggle('low', S.timer.left <= 10);
  }, 200);
}
function stopTimer() { clearInterval(tick); if (S.timer) S.timer.running = false; }

async function comment(kind, who) {
  try {
    const r = await api('/api/commentary', { kind, who }, 4000);
    S.commentary = r.line;
  } catch { S.commentary = ''; }
}

// one host decision at a time (prevents double-taps scoring twice)
let busy = false;
const guarded = (fn) => async () => {
  if (busy || !S.card || (S.game.secret && !S.revealed)) return;
  busy = true;
  try { await fn(); } finally { busy = false; }
};

async function onCorrect() {
  const g = S.game;
  const p = current();
  const pts = S.settings.points;
  saveLine();

  if (g.id === 'football') {
    S.zone += 1;
    if (S.zone >= 3) {
      award(p.id, pts);
      await comment('goal', p.name);
      toast(`⚽ GOAL! ${p.name} +${pts}`);
      return endTurn(true);
    }
    await comment('correct', p.name);
    toast(`Ball moves to the ${ZONES[S.zone]}!`);
    return dealCard();
  }

  const earned = (g.id === 'market' || g.id === 'proverb') && S.attempt > 0 ? half(pts) : pts;
  award(p.id, earned);
  if (g.mode === 'team') await comment('correct', p.name);
  toast(`✓ ${p.name} +${earned}`);
  endTurn(true);
}

async function onAgain() {
  const p = current();
  if (S.attempt === 0) {
    S.attempt = 1;
    if (S.game.id === 'football') await comment('retry', p.name);
    // a little extra time for the second try, never more than the full timer
    S.timer.left = Math.min(S.timer.total, Math.max(S.timer.left, Math.round(S.timer.total / 2)));
    S.timer.up = false;
    if (!S.game.secret || S.revealed) { S.timer.running = true; runTimer(); }
    renderKeepScroll();
    return;
  }
  saveLine();
  if (S.game.id === 'football') { await comment('miss', p.name); toast(`🧤 Saved! ${p.name}'s attack ends.`); }
  else toast(`No points for ${p.name} this time.`);
  endTurn(false);
}

const doCorrect = guarded(onCorrect);
const doAgain = guarded(onAgain);

function saveLine() {
  if (!S.game.story) return;
  const v = (document.getElementById('line')?.value || '').trim().slice(0, 200);
  if (v) S.storyLines.push(`${current().name}: ${v}`);
}

function award(id, pts) {
  if (S.tiebreak) S.tbScores[id] = (S.tbScores[id] || 0) + pts;
  else {
    S.scores[id] += pts;
    S.rounds[S.rounds.length - 1][id] += pts;
  }
}

function endTurn() {
  stopTimer();
  S.card = null;
  S.turn += 1;
  if (S.turn < S.order.length) {
    // short pause so the toast/commentary lands before the next card
    S.cardLoading = true;
    render();
    setTimeout(startTurn, 900);
    return;
  }
  if (S.tiebreak) return finishTiebreak();
  S.screen = 'round';
  render();
}

function nextAfterRound() {
  if (S.rounds.length < S.settings.rounds) {
    S.round += 1;
    return startRound();
  }
  finishGame();
}

function leaders(scoreFn, ids) {
  const max = Math.max(...ids.map(scoreFn));
  return ids.filter((id) => scoreFn(id) === max);
}

function finishGame() {
  const top = leaders((id) => S.scores[id], S.participants.map((p) => p.id));
  if (top.length === 1) return showResults(top, false);
  if (S.settings.tiebreak === 'share') return showResults(top, true, 'share');
  S.tiebreak = 1;
  S.tbContenders = top;
  top.forEach((id) => { S.tbScores[id] = 0; });
  toast(`⚡ Tie! Sudden death between ${top.map((id) => pById(id).name).join(' & ')}`);
  startTiebreakRound();
}

function startTiebreakRound() {
  S.order = [...S.tbContenders];
  S.turn = 0;
  startTurn();
}

function finishTiebreak() {
  const top = leaders((id) => S.tbScores[id] || 0, S.tbContenders);
  if (top.length === 1) return showResults(top, false);
  if (S.tiebreak >= MAX_TIEBREAKS) return showResults(top, true, 'max');
  S.tiebreak += 1;
  S.tbContenders = top;
  toast(`Still level! Sudden death ${S.tiebreak}/${MAX_TIEBREAKS}`);
  startTiebreakRound();
}

function showResults(winners, shared, reason) {
  stopTimer();
  S.results = { winners, shared, reason, tb: S.tiebreak > 0 };
  const passport = store.get('majlis-passport', []);
  passport.push({ game: S.game.id, winners: winners.map((id) => pById(id).name), at: Date.now() });
  store.set('majlis-passport', passport.slice(-50));
  S.screen = 'results';
  render();
}

async function makeStory() {
  const winner = S.results.winners.map((id) => pById(id).name).join(' & ');
  S.finale = { loading: true };
  render();
  try {
    const r = await api('/api/story-final', { lines: S.storyLines, winner }, 20000);
    S.finale = { ...r, img: null };
    const imgPrompt = r.imagePrompt || `a joyful family celebrating ${winner || 'together'} with a golden trophy in a cosy majlis living room`;
    if (S.status.imagesConfigured) {
      S.finale.img = { state: 'loading' };
      renderKeepScroll();
      S.finale.img = await makeImage(imgPrompt);
    }
  } catch {
    S.finale = null;
    toast('Could not reach the server for the story. Try again.');
  }
  renderKeepScroll();
}

// ---------- events ----------
function bind() {
  app.querySelectorAll('[data-pick]').forEach((b) => b.addEventListener('click', () => {
    S.game = gameById(b.dataset.pick);
    S.settings = null;
    go('players');
  }));
  app.querySelectorAll('[data-go]').forEach((b) => b.addEventListener('click', () => go(b.dataset.go)));

  const pf = document.getElementById('players-form');
  if (pf) pf.addEventListener('submit', (e) => {
    e.preventDefault();
    const fd = new FormData(pf);
    const names = [0, 1, 2, 3].map((i) => String(fd.get(`p${i}`) || '').trim());
    const err = validateNames(names);
    pf.querySelectorAll('input[name^=p]').forEach((inp, i) => inp.setAttribute('aria-invalid', err && err.bad.includes(i) ? 'true' : 'false'));
    if (err) { document.getElementById('form-error').textContent = err.msg; return; }
    S.names = names;
    S.facts = { hometown: String(fd.get('hometown') || '').trim(), dish: String(fd.get('dish') || '').trim(), sport: String(fd.get('sport') || '').trim() };
    store.set('majlis-setup', { names: S.names, facts: S.facts });
    buildParticipants();
    go('rules');
  });

  const rf = document.getElementById('rules-form');
  if (rf) rf.addEventListener('submit', (e) => {
    e.preventDefault();
    const fd = new FormData(rf);
    const num = (k) => Number(fd.get(k));
    const points = num('points'), seconds = num('seconds'), rounds = num('rounds');
    const errs = [];
    if (!Number.isInteger(points) || points < 1 || points > 10) errs.push(['points', 'Points must be a whole number from 1 to 10.']);
    if (!Number.isInteger(seconds) || seconds < 15 || seconds > 180) errs.push(['seconds', 'Seconds must be a whole number from 15 to 180.']);
    if (!Number.isInteger(rounds) || rounds < 1 || rounds > 5) errs.push(['rounds', 'Rounds must be a whole number from 1 to 5.']);
    rf.querySelectorAll('input[type=number]').forEach((i) => i.setAttribute('aria-invalid', errs.some(([k]) => k === i.name) ? 'true' : 'false'));
    if (errs.length) { document.getElementById('form-error').textContent = errs.map(([, m]) => m).join(' '); return; }
    S.settings = { points, seconds, rounds, difficulty: fd.get('difficulty') || 'medium', tiebreak: fd.get('tiebreak') || 'sudden' };
    S.ready = {};
    go('ready');
  });

  app.querySelectorAll('[data-ready]').forEach((b) => b.addEventListener('click', () => {
    S.ready[b.dataset.ready] = !S.ready[b.dataset.ready];
    render();
  }));
  on('kickoff', startGame);

  on('correct', doCorrect);
  on('again', doAgain);
  on('newcard', () => { saveDraft(); dealCard(); });
  on('retry', dealCard);
  on('reveal', () => { S.revealed = true; startTimer(); render(); });
  on('show-answer', () => { S.answerShown = !S.answerShown; renderKeepScroll(); });
  on('pause', () => {
    if (S.timer.running) { stopTimer(); } else { S.timer.running = true; runTimer(); }
    renderKeepScroll();
  });

  on('next-round', nextAfterRound);
  on('again-same', () => { S.ready = {}; go('ready'); });
  on('other-game', () => go('pick'));
  on('make-story', makeStory);
}

function saveDraft() { const v = document.getElementById('line')?.value; if (v !== undefined) S.lineDraft = v; }
function on(id, fn) { const el = document.getElementById(id); if (el) el.addEventListener('click', fn); }

function validateNames(names) {
  const empty = names.map((n, i) => (n ? -1 : i)).filter((i) => i >= 0);
  if (empty.length) return { msg: `Please enter a name for ${empty.map((i) => `P${i + 1}`).join(', ')}.`, bad: empty };
  const lower = names.map((n) => n.toLowerCase());
  const dup = lower.map((n, i) => (lower.indexOf(n) !== i ? i : -1)).filter((i) => i >= 0);
  if (dup.length) return { msg: 'Each player needs a different name (add an initial, like "Sara K").', bad: dup };
  if (names.some((n) => !/[\p{L}\p{N}]/u.test(n))) return { msg: 'Names need at least one letter or number.', bad: names.map((n, i) => (/[\p{L}\p{N}]/u.test(n) ? -1 : i)).filter((i) => i >= 0) };
  return null;
}

exitBtn.addEventListener('click', () => {
  if (S.screen === 'turn' || S.screen === 'round') {
    if (!confirm('Leave this game? Scores for this game will be lost.')) return;
  }
  go('pick');
});

// keyboard shortcuts for the host: C = correct, T = try again / miss, P = pause
document.addEventListener('keydown', (e) => {
  if (S.screen !== 'turn' || !S.card || /input|textarea/i.test(e.target.tagName)) return;
  const k = e.key.toLowerCase();
  if (k === 'c') doCorrect();
  else if (k === 't') doAgain();
  else if (k === 'p') document.getElementById('pause')?.click();
});

// deep link from the landing page: /play.html?game=football
const qs = new URLSearchParams(location.search).get('game');
if (qs && gameById(qs)) { S.game = gameById(qs); S.screen = 'players'; }
render();
