# Demo script (about 4 minutes)

1. **Landing (40 s).** Open http://localhost:3000. Move the mouse over the 3D "Majlis Arena" title, then scroll through the line-up, the football section and the AI section. Say: "Five games, one shared flow, AI makes the cards, and it works offline."
2. **Start (20 s).** Click *Start game night*, then pick **World Cup Match**.
3. **Players (20 s).** Type Mama, Baba, Sara, Omar. Point out that Team A = P1+P2 and Team B = P3+P4. Open *family facts* and type a hometown.
4. **Rules + ready (20 s).** 2 rounds, 3 points, 30 seconds, sudden death. Each team taps Ready, and the kick-off button unlocks.
5. **Play (90 s).** Show the source chip (GEMINI or OFFLINE DECK). Tap *Host: show answer*. Correct ×3 makes the ball move and scores a GOAL, with commentary. For Team B, tap Try Again to show the hint, then Miss for "Saved!".
6. **Round scores → results (30 s).** Show the round table, the champion screen and the passport stamp.
7. **Switch games (30 s).** Choose *Festival Charades* to show the secret card and actor/guesser roles. Optionally, *Story Chest* → front page.
8. **Honesty line (10 s).** "If Gemini fails, the offline deck takes over, and the badge says so."

Backup: if the Wi-Fi fails, everything still runs. Just say "offline deck mode".
