// The five games. Each one plugs into the shared engine in play.js.
// mode: 'team' (Team A = P1+P2 vs Team B = P3+P4) or 'solo' (P1–P4 each).
// cardsPerTurn > 1 means a turn is a "drive" (football attack) of several cards.

export const GAMES = [
  {
    id: 'football',
    name: 'World Cup Match',
    icon: '/img/icons/soccer.png',
    mode: 'team',
    tag: 'FLAGSHIP · FOOTBALL',
    blurb: 'Answer football riddles to dribble up the pitch. Three correct in one attack is a GOAL.',
    rules: [
      'Teams take turns to attack. Each attack starts at midfield.',
      'Correct moves the ball one zone: Midfield → Attack → Box → GOAL.',
      'Try Again shows a hint. A second miss means the keeper saves it and the attack ends.',
      'A goal scores your chosen points.'
    ],
    cardsPerTurn: 3,
    defaults: { points: 3, seconds: 45, rounds: 3 },
    hostAnswer: true
  },
  {
    id: 'market',
    name: 'Market Mystery',
    icon: '/img/icons/basket.png',
    mode: 'solo',
    tag: 'AI PICTURE · GEOGRAPHY',
    blurb: 'The AI describes (and can paint) a busy market. Name the country.',
    rules: [
      'P1 to P4 take turns. Each turn is one market.',
      'Read the scene aloud. The player guesses the country.',
      'Correct first time = full points. With the hint (after Try Again) = half points.'
    ],
    cardsPerTurn: 1,
    defaults: { points: 2, seconds: 60, rounds: 2 },
    image: true,
    hostAnswer: true
  },
  {
    id: 'festival',
    name: 'Festival Charades',
    icon: '/img/icons/popper.png',
    mode: 'team',
    tag: 'ACT IT OUT · CULTURE',
    blurb: 'One teammate acts out a festival. No talking! The other guesses.',
    rules: [
      'The actor taps Reveal. The guesser must look away from the screen.',
      'Act out the festival using the suggested actions. No words, no sounds.',
      'Guessed it before time runs out? The host taps Correct.',
      'The actor and guesser swap every round.'
    ],
    cardsPerTurn: 1,
    defaults: { points: 2, seconds: 60, rounds: 2 },
    secret: true,
    hostAnswer: false
  },
  {
    id: 'proverb',
    name: "Grandma's Proverb",
    icon: '/img/icons/balloon.png',
    mode: 'solo',
    tag: 'WORDS · WISDOM',
    blurb: 'Finish a well-known proverb from around the world, or explain what it means.',
    rules: [
      'Read the first half aloud.',
      'The player finishes it or explains the meaning in their own words.',
      'Close enough counts. The host decides!',
      'Correct first time = full points. With the hint = half points.'
    ],
    cardsPerTurn: 1,
    defaults: { points: 2, seconds: 40, rounds: 2 },
    hostAnswer: true
  },
  {
    id: 'story',
    name: 'Story Chest Finale',
    icon: '/img/icons/scroll.png',
    mode: 'team',
    tag: 'FINALE · STORYTELLING',
    blurb: 'Tell the next line of the family story using three must-use words. The AI writes the finale.',
    rules: [
      'Each team gets a setting plus three words they must use.',
      'Tell one or two story lines aloud before time runs out. You can type it too.',
      'All three words used? The host taps Correct.',
      'At the end, the AI turns every line into one family story and a newspaper front page.'
    ],
    cardsPerTurn: 1,
    defaults: { points: 3, seconds: 75, rounds: 2 },
    story: true,
    hostAnswer: false
  }
];

export const gameById = (id) => GAMES.find((g) => g.id === id);
