# Majlis Arena · Ad Voiceover Script (≈2:20)

**Tone:** energetic, warm, hype-sports-commentator mixed with a friendly older cousin.
**Music:** quiet ticking/clock for the problem, then a big beat drop at 0:30, upbeat percussion (darbuka + electronic) to the end.
**Pace:** ~150 words/min. **Bold** = punch the word. `/` = short pause. `//` = long pause (let the music hit).

---

## 1 · HOOK (0:00 – 0:08)
**Screen:** black screen → phone notification sounds stacking up → family on a sofa, every face lit blue by a phone.
**On-screen text:** *SAME SOFA. DIFFERENT PLANETS.*

> **VO (slow, quiet):** Same sofa. / Same family. // Different planets.

## 2 · THE PROBLEM (0:08 – 0:30)
**Screen:** quick cuts. Kid scrolling, dad on a work call, grandma holding the remote alone, an old board game box gathering dust, a clock ticking.
**On-screen text:** *1 ROOM · 4 SCREENS · 0 CONVERSATIONS*

> **VO (building):** Be honest. / Family night has become… everyone on their own phone. / The kids are bored of the old board games. / Grandma and grandpa get left out of the new ones. / And every time someone says "let's play something together"… / **nobody** can agree what. //
> We didn't need **another** app to pull us apart. / We needed one that pulls us **back together**.

## 3 · THE TURN (0:30 – 0:42) 🔊 BEAT DROP
**Screen:** music explodes. The glossy 3D "Majlis Arena" title spins in (screen-record the landing page hero).
**On-screen text:** *MAJLIS ARENA · YALLAH GAMES!*

> **VO (full energy):** So we built it. // Welcome to **Majlis Arena**! / Five games. / One family. / **One champion.** / Yallah!

## 4 · THE SOLUTION: FIVE GAMES (0:42 – 1:35)
**Screen:** screen recordings of each game, fast cuts, the score popping up.

**World Cup Match (0:42 – 0:55)** · *TEAM A vs TEAM B*
> **VO:** First up: the **World Cup Match**! / Team A versus Team B. / Answer the AI's football riddles, / move the ball up the pitch… / midfield, attack, the box… / **GOOOAL!**

**Market Mystery (0:55 – 1:05)** · *SOLO*
> **VO:** **Market Mystery.** / Spices, lanterns, mint tea… / the AI drops you in a busy market somewhere on Earth. / Which country are you in?

**Festival Charades (1:05 – 1:15)** · *TEAM*
> **VO:** **Festival Charades!** / One secret card. / No talking. / Act out Eid, Diwali, Lunar New Year… / before the clock runs out!

**Grandma's Proverb (1:15 – 1:24)** · *SOLO*
> **VO:** **Grandma's Proverb.** / "Trust in God…" / …but tie your camel. // Finally, a game where grandma is the **champion**.

**Story Chest Finale (1:24 – 1:35)** · *TEAM*
> **VO:** And the grand finale: / the **Story Chest**. / Three crazy words, / one family story, / and the AI prints your winner on tonight's **front page**!

## 5 · HOW IT WORKS (1:35 – 1:55)
**Screen:** fast montage of the six setup steps: pick game → P1–P4 → rules → Ready → AI card → host taps Correct.
**On-screen text:** *PICK · PLAY · CROWN*

> **VO (rapid-fire, rhythmic):** Pick a game. / Pick your players: P1, P2, P3, P4. / Set the points, / the timer, / the tie-break. / Everyone ready? // The AI deals a fresh card, / and the **host** decides: / Correct… / or Try Again. / Scores update **live**. / And if it's a tie? / **Sudden death!**

## 6 · WHY FAMILIES TRUST IT (1:55 – 2:10)
**Screen:** the "Powered by Gemini. Works offline too." section, the OFFLINE DECK badge, the family facts form.
**On-screen text:** *NO LOGIN · FAMILY-FRIENDLY · WORKS OFFLINE*

> **VO (warm, confident):** The clues are made by AI, / with strict family-friendly rules / and respect for every culture. / Tell it your hometown, / your favourite dish, / and the cards become about **your** family. / No accounts. / And if the internet drops? / Our offline deck keeps the game going.

## 7 · CALL TO ACTION (2:10 – 2:22)
**Screen:** back to the sofa. Phones face down on the table. Everyone jumping up, cheering. The crown appears on the winner. Cut to the giant "Yallah!" + logo.
**On-screen text:** *PUT THE PHONES DOWN. PICK A GAME. · MAJLIS ARENA*

> **VO (biggest energy, then smile in the voice):** So tonight… / put the phones down, / pour the tea, / and pick a game. // **Majlis Arena.** / Where families play together. // **Yallah!**

**SFX:** crowd cheer + whistle on the last word. 2 seconds of logo on screen, then cut.

---

### Recording tips
- Read the whole script once **before** recording. It runs ≈2:15–2:25 at a lively pace.
- Smile while you read the energetic parts. People can hear it.
- Record each numbered section as a separate take so mistakes are easy to fix.
- Leave about 1 second of silence before and after each take for editing.

### Claims check (all true for the current app)
✅ 5 games, P1–P4, Team A/B, timer, tie-break, host decides · ✅ Gemini AI text cards · ✅ family facts · ✅ no login · ✅ offline deck
⚠️ AI pictures need a Gemini key with image quota (the current free key has none). The script never promises pictures.
