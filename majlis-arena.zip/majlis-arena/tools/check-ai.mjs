// Checks the Gemini setup in .env: lists the model IDs your key can use, then
// makes one tiny text call and one image call. Run: npm run check-ai
const KEY = process.env.GEMINI_API_KEY;
const TEXT = process.env.GEMINI_TEXT_MODEL;
const IMAGE = process.env.GEMINI_IMAGE_MODEL;
const API = 'https://generativelanguage.googleapis.com/v1beta';

if (!KEY) {
  console.log('No GEMINI_API_KEY in .env. The app will run with the offline decks.');
  process.exit(0);
}

const headers = { 'content-type': 'application/json', 'x-goog-api-key': KEY };

const list = await fetch(`${API}/models?pageSize=200`, { headers });
if (!list.ok) {
  console.log(`Could not list models (HTTP ${list.status}). Check the key.`);
  process.exit(1);
}
const ids = (await list.json()).models.map((m) => m.name.replace('models/', '')).filter((n) => n.includes('gemini'));
console.log('Gemini models your key can use:\n  ' + ids.join('\n  '));

for (const [label, model, body] of [
  ['text', TEXT, { contents: [{ parts: [{ text: 'Reply with the JSON {"ok":true}' }] }], generationConfig: { responseMimeType: 'application/json' } }],
  ['image', IMAGE, { contents: [{ parts: [{ text: 'A small glossy 3D football, no text' }] }], generationConfig: { responseModalities: ['IMAGE'] } }]
]) {
  if (!model) { console.log(`\n${label}: no model set in .env`); continue; }
  const r = await fetch(`${API}/models/${encodeURIComponent(model)}:generateContent`, { method: 'POST', headers, body: JSON.stringify(body) });
  const d = await r.json().catch(() => ({}));
  const parts = d?.candidates?.[0]?.content?.parts || [];
  const gotImage = parts.some((p) => p.inlineData?.data);
  const ok = r.ok && (label === 'image' ? gotImage : parts.length > 0);
  console.log(`\n${label} model "${model}": ${ok ? 'WORKS' : `FAILED (HTTP ${r.status}) ${d?.error?.message || ''}`}`);
}
