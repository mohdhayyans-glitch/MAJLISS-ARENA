// Majlis Arena server: serves the site and the Gemini AI endpoints.
// The API key is read only here, from .env. It is never sent to the browser.
// Any AI failure (no key, timeout, bad JSON, safety block) falls back to the offline deck.
import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { decks, commentary } from './data/decks.js';

const root = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = Number(process.env.PORT) || 3000;

const KEY = process.env.GEMINI_API_KEY || '';
const TEXT_MODEL = process.env.GEMINI_TEXT_MODEL || '';
const IMAGE_MODEL = process.env.GEMINI_IMAGE_MODEL || '';
const API = 'https://generativelanguage.googleapis.com/v1beta/models';
// Set when Google answers 429 (quota) for images: stop asking until the server restarts.
let imagesBlocked = false;

app.use(express.json({ limit: '64kb' }));
// no-cache: browsers revalidate, so edits to the site always show on refresh
app.use(express.static(path.join(root, 'public'), { setHeaders: (res) => res.setHeader('Cache-Control', 'no-cache') }));
// three.js served from node_modules so the site works without a CDN.
app.use('/vendor/three', express.static(path.join(root, 'node_modules/three')));
app.use('/fonts/rubik', express.static(path.join(root, 'node_modules/@fontsource/rubik/files')));

// ---------- prompts ----------
const SYSTEM = `You write content for "Majlis Arena", a family game night for ages 11+ playing with parents and grandparents.
Rules: family-friendly, kind, culturally respectful. Never mock any culture, religion or people.
Only use widely known, accurate facts. If unsure of a fact, pick a different one.
No violence, romance, scary content, alcohol or brand promotion. Short, clear English that a 12-year-old understands.
Reply with JSON only, matching the requested shape exactly.`;

const GAME_PROMPTS = {
  football: (o) => `Make one football (soccer) riddle or trivia question for difficulty "${o.difficulty}".
Mix world football history, rules, famous tournaments, and football in the Arab world and other regions.
${facts(o)}
Shape: {"clue": "the riddle, max 35 words", "answer": "short answer", "hint": "a helpful hint that doesn't give it away", "fact": "one fun true fact, max 25 words"}`,
  market: (o) => `Describe one real, busy market somewhere in the world so players can guess the country. Difficulty "${o.difficulty}".
Mention 3 vivid details (foods, crafts, sounds, smells) but never name the country or city.
${facts(o)}
Shape: {"clue": "market scene, max 45 words", "answer": "the country", "hint": "a geography hint", "fact": "one fun true fact about that country's markets or food, max 25 words", "imagePrompt": "a short visual description of the market scene, no text, no country name"}`,
  festival: (o) => `Pick one real festival or celebration from anywhere in the world for a charades round (acting, no talking). Difficulty "${o.difficulty}".
Choose ones that are joyful and appropriate to act out respectfully.
Shape: {"clue": "Festival name (where it is celebrated)", "answer": "festival name", "hint": "Act: 2-3 simple actions to mime", "fact": "one true fact about it, max 25 words"}`,
  proverb: (o) => `Give the first half of one well-known proverb from any culture (Arabic, Chinese, Japanese, African, English, etc.). Difficulty "${o.difficulty}".
Shape: {"clue": "first half ending with …", "answer": "…the second half", "hint": "a clue to the meaning", "fact": "where it comes from and what it means, max 25 words"}`,
  story: (o) => `Make one story-chest prompt for a team to tell one or two story lines aloud. Give a fun setting and exactly three words they must use (mix a heritage item, a family member and something silly).
${facts(o)}
Shape: {"clue": "Setting: ... Use all three words: word1, word2, word3.", "answer": "Any story line that uses all 3 words", "hint": "a story starter", "fact": "one true fact related to one of the words, max 25 words"}`,
  storyFinal: (o) => `Write the final family story for tonight's game, 120-170 words, warm and funny, using these lines the teams told: ${JSON.stringify(o.lines || []).slice(0, 1500)}.
The winner is ${o.winner || 'everyone'}. Also write a newspaper headline.
Shape: {"headline": "max 9 words", "story": "the story", "imagePrompt": "a short visual description for a newspaper front-page illustration of the family celebrating, no text"}`
};

function facts(o) {
  const f = o.familyFacts || {};
  const list = [f.hometown && `hometown: ${f.hometown}`, f.dish && `favourite family dish: ${f.dish}`, f.sport && `favourite sport: ${f.sport}`].filter(Boolean);
  const avoid = (o.used || []).slice(-20).join(' | ');
  return [
    list.length ? `If it fits naturally, connect to this family (${list.join(', ')}), but keep the facts accurate.` : '',
    avoid ? `Do NOT reuse these answers: ${avoid}.` : ''
  ].join('\n');
}

const clean = (s, n = 60) => String(s ?? '').replace(/[\u0000-\u001f<>]/g, ' ').trim().slice(0, n);

// Google sometimes answers 500/503 ("busy"): retry once after a short pause before falling back.
async function geminiText(prompt) {
  try {
    return await geminiTextOnce(prompt);
  } catch (err) {
    if (!/HTTP 50[03]/.test(err.message)) throw err;
    await new Promise((r) => setTimeout(r, 900));
    return geminiTextOnce(prompt);
  }
}

async function geminiTextOnce(prompt) {
  const res = await fetch(`${API}/${encodeURIComponent(TEXT_MODEL)}:generateContent`, {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'x-goog-api-key': KEY },
    body: JSON.stringify({
      systemInstruction: { parts: [{ text: SYSTEM }] },
      contents: [{ role: 'user', parts: [{ text: prompt }] }],
      generationConfig: { responseMimeType: 'application/json', temperature: 1 }
    }),
    signal: AbortSignal.timeout(12000)
  });
  if (!res.ok) throw new Error(`Gemini text HTTP ${res.status}`);
  const data = await res.json();
  const text = data?.candidates?.[0]?.content?.parts?.map((p) => p.text || '').join('') || '';
  return JSON.parse(text.replace(/^```(json)?|```$/g, '').trim());
}

function pickOffline(game, used = []) {
  const deck = decks[game] || decks.football;
  const fresh = deck.filter((c) => !used.includes(c.answer));
  const pool = fresh.length ? fresh : deck;
  return pool[Math.floor(Math.random() * pool.length)];
}

// ---------- endpoints ----------
app.get('/api/status', (_req, res) => {
  res.json({ aiConfigured: Boolean(KEY && TEXT_MODEL), imagesConfigured: Boolean(KEY && IMAGE_MODEL) && !imagesBlocked });
});

app.post('/api/card', async (req, res) => {
  const game = clean(req.body?.game, 20);
  const opts = {
    difficulty: ['easy', 'medium', 'hard'].includes(req.body?.difficulty) ? req.body.difficulty : 'medium',
    used: Array.isArray(req.body?.used) ? req.body.used.map((u) => clean(u, 60)).slice(-30) : [],
    familyFacts: {
      hometown: clean(req.body?.familyFacts?.hometown, 40),
      dish: clean(req.body?.familyFacts?.dish, 40),
      sport: clean(req.body?.familyFacts?.sport, 40)
    }
  };
  if (!GAME_PROMPTS[game] || game === 'storyFinal') return res.status(400).json({ error: 'Unknown game' });

  if (KEY && TEXT_MODEL) {
    try {
      const c = await geminiText(GAME_PROMPTS[game](opts));
      if (c && typeof c.clue === 'string' && typeof c.answer === 'string' && c.clue.length > 3) {
        return res.json({
          source: 'ai',
          card: {
            clue: clean(c.clue, 400), answer: clean(c.answer, 120), hint: clean(c.hint, 200),
            fact: clean(c.fact, 220), imagePrompt: clean(c.imagePrompt, 300)
          }
        });
      }
      throw new Error('AI card missing fields');
    } catch (err) {
      console.warn(`[card:${game}] using offline deck:`, err.message);
    }
  }
  res.json({ source: 'offline', card: pickOffline(game, opts.used) });
});

app.post('/api/story-final', async (req, res) => {
  const lines = Array.isArray(req.body?.lines) ? req.body.lines.map((l) => clean(l, 200)).filter(Boolean).slice(0, 12) : [];
  const winner = clean(req.body?.winner, 60);
  if (KEY && TEXT_MODEL) {
    try {
      const s = await geminiText(GAME_PROMPTS.storyFinal({ lines, winner }));
      if (s?.story && s?.headline) {
        return res.json({ source: 'ai', headline: clean(s.headline, 90), story: clean(s.story, 1400), imagePrompt: clean(s.imagePrompt, 300) });
      }
    } catch (err) {
      console.warn('[story-final] offline:', err.message);
    }
  }
  const body = lines.length
    ? `Tonight in the majlis, the family told a story together. ${lines.join(' ')} And when the last line was told, everyone laughed, the tea was poured, and ${winner || 'the whole family'} raised the trophy.`
    : `Tonight in the majlis, the family played, laughed and told stories until the tea went cold. ${winner || 'Everyone'} raised the trophy.`;
  res.json({ source: 'offline', headline: `${winner || 'Family'} Wins Majlis Arena!`, story: body, imagePrompt: '' });
});

app.post('/api/image', async (req, res) => {
  const prompt = clean(req.body?.prompt, 300);
  if (!KEY || !IMAGE_MODEL || !prompt) return res.json({ ok: false, reason: 'not-configured' });
  if (imagesBlocked) return res.json({ ok: false, reason: 'quota' });
  try {
    const r = await fetch(`${API}/${encodeURIComponent(IMAGE_MODEL)}:generateContent`, {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-goog-api-key': KEY },
      body: JSON.stringify({
        contents: [{ role: 'user', parts: [{ text: `Bright, friendly, glossy 3D illustration for a family game, soft lighting, no words or letters: ${prompt}` }] }],
        generationConfig: { responseModalities: ['IMAGE'] }
      }),
      signal: AbortSignal.timeout(30000)
    });
    if (r.status === 429) imagesBlocked = true;
    if (!r.ok) throw new Error(`Gemini image HTTP ${r.status}`);
    const data = await r.json();
    const part = data?.candidates?.[0]?.content?.parts?.find((p) => p.inlineData?.data);
    if (!part) throw new Error('no image in response');
    res.json({ ok: true, src: `data:${part.inlineData.mimeType || 'image/png'};base64,${part.inlineData.data}` });
  } catch (err) {
    console.warn('[image] failed:', err.message);
    res.json({ ok: false, reason: 'failed' });
  }
});

// Commentary uses the canned lines (instant, no extra AI call per tap).
app.post('/api/commentary', (req, res) => {
  const kind = ['correct', 'goal', 'miss', 'retry'].includes(req.body?.kind) ? req.body.kind : 'correct';
  const who = clean(req.body?.who, 40) || 'The team';
  const lines = commentary[kind];
  res.json({ line: lines[Math.floor(Math.random() * lines.length)].replaceAll('{who}', who) });
});

app.listen(PORT, () => {
  console.log(`Majlis Arena running at http://localhost:${PORT}`);
  console.log(KEY ? `Gemini: text=${TEXT_MODEL || '(missing)'} image=${IMAGE_MODEL || '(missing)'}` : 'Gemini: no key, using offline decks');
});
