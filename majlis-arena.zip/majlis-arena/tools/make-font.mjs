// One-off: converts the Rubik Black font (OFL) into three.js typeface JSON so the
// 3D title loads offline. Same conversion as three's TTFLoader, run at build time.
// Usage: node tools/make-font.mjs
import fs from 'node:fs';
import opentype from 'opentype.js';

const src = 'node_modules/@fontsource/rubik/files/rubik-latin-900-normal.woff';
const out = 'public/fonts/rubik-black.typeface.json';

const buf = fs.readFileSync(src);
const font = opentype.parse(buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength));
const round = Math.round;
const scale = 100000 / ((font.unitsPerEm || 2048) * 72);
const glyphs = {};

for (let i = 0; i < font.glyphs.length; i++) {
  const glyph = font.glyphs.get(i);
  if (!glyph.unicodes || glyph.unicodes.length === 0) continue;
  const token = {
    ha: round(glyph.advanceWidth * scale),
    x_min: round((glyph.xMin || 0) * scale),
    x_max: round((glyph.xMax || 0) * scale),
    o: ''
  };
  for (const c of glyph.path.commands) {
    const type = c.type.toLowerCase() === 'c' ? 'b' : c.type.toLowerCase();
    token.o += type + ' ';
    if (c.x !== undefined) token.o += round(c.x * scale) + ' ' + round(c.y * scale) + ' ';
    if (c.x1 !== undefined) token.o += round(c.x1 * scale) + ' ' + round(c.y1 * scale) + ' ';
    if (c.x2 !== undefined) token.o += round(c.x2 * scale) + ' ' + round(c.y2 * scale) + ' ';
  }
  for (const u of glyph.unicodes) glyphs[String.fromCodePoint(u)] = token;
}

const json = {
  glyphs,
  familyName: 'Rubik Black',
  ascender: round(font.ascender * scale),
  descender: round(font.descender * scale),
  underlinePosition: font.tables.post.underlinePosition,
  underlineThickness: font.tables.post.underlineThickness,
  boundingBox: {
    xMin: font.tables.head.xMin, xMax: font.tables.head.xMax,
    yMin: font.tables.head.yMin, yMax: font.tables.head.yMax
  },
  resolution: 1000,
  original_font_information: { license: 'SIL Open Font License 1.1 (Rubik, via @fontsource/rubik)' }
};

fs.mkdirSync('public/fonts', { recursive: true });
fs.writeFileSync(out, JSON.stringify(json));
console.log(`wrote ${out} with ${Object.keys(glyphs).length} glyphs`);
