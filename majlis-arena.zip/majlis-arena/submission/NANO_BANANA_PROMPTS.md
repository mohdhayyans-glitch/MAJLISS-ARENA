# Nano Banana image prompts for the ad (15)

**How to use:** generate each image in **16:9 landscape**, save it with the file name shown (e.g. `01-hook.png`), and send them to me. I'll drop them into the video. Game scenes already use real app screenshots, so these are only for the story moments around them.

**Paste this style line at the end of every prompt** so all 15 match:
> *Cinematic photo-real 3D render, dark moody room with glowing violet, teal and lime neon light accents, soft volumetric light, shallow depth of field, rich contrast, 16:9, no text, no logos, no brand names.*

| # | File name | When it appears | Prompt |
|---|-----------|-----------------|--------|
| 1 | `01-hook.png` | 0:00 "Same sofa…" | A Gulf Arab family of four (father, mother in a hijab, a teenage girl, a young boy) sitting side by side on a big majlis floor sofa at night, all looking down at their own phones, faces lit blue by the screens, not talking, the room dark around them |
| 2 | `02-phones.png` | 0:05 "everyone on their own phone" | Close-up over-the-shoulder shot of four glowing phone screens in four different hands on one sofa, blurred living room background, blue screen light on the faces |
| 3 | `03-bored-kid.png` | 0:09 "kids are bored" | A bored 12-year-old boy slumped on cushions, chin on his hand, an old faded board game box closed beside him, scrolling a phone without interest, warm lamp in the background |
| 4 | `04-grandparents.png` | 0:12 "grandparents left out" | A kind grandmother in a traditional abaya and a grandfather in a white thobe sitting alone at the end of a majlis with small cups of Arabic coffee, watching their family on phones across the room, slightly sad and lonely, warm light on them |
| 5 | `05-dusty-boardgame.png` | 0:15 "let's play something together" | A dusty, unopened board game box and scattered playing cards on a wooden coffee table, cobwebs, a single beam of light falling on it, phones glowing out of focus in the background |
| 6 | `06-arguing.png` | 0:19 "nobody agrees" | A family on a sofa playfully arguing, each pointing at a different idea, exaggerated funny expressions, the dad holding a remote, the kids holding phones, cartoonish but realistic 3D style |
| 7 | `07-apart.png` | 0:21 "pull us apart" | Top-down view of a living room where each family member sits on a separate cushion far apart, each in their own glowing bubble of phone light, empty dark space between them |
| 8 | `08-together.png` | 0:23 "pulls us back together" | The same family now leaning in together around one tablet on the coffee table, smiling, the tablet glowing violet and lime, warm light filling the room |
| 9 | `09-built.png` | 0:26 "So we built it" | A glowing glossy violet glass game controller and a lime football floating above an open laptop in a dark room, sparks and light particles, futuristic and exciting |
| 10 | `10-ai-safe.png` | 1:46 "family-friendly AI" | A friendly cute 3D robot holding a glowing card with a soft shield symbol, standing on a coffee table next to a teapot, cosy majlis behind it, warm and trustworthy |
| 11 | `11-hometown.png` | 1:51 "your hometown, your favourite dish" | A beautiful steaming platter of machboos (spiced rice with chicken) on a majlis floor mat with small cups of karak tea, the city lights of Muscat through a window behind, warm and inviting |
| 12 | `12-offline.png` | 1:56 "internet drops?" | A family laughing and playing a game on a tablet while a Wi-Fi router in the corner shows a red light, the family doesn't care, lanterns glowing, fun and relaxed |
| 13 | `13-tonight.png` | 2:01 "So tonight…" | Four phones placed face-down in a woven basket on a coffee table, a family in soft focus behind getting excited, golden evening light |
| 14 | `14-tea.png` | 2:03 "pour the tea" | A hand pouring golden tea from a traditional brass dallah coffee pot into small cups, steam rising, dates in a bowl, glowing violet and lime rim light |
| 15 | `15-celebrate.png` | 2:06 "Majlis Arena!" | The whole family (grandparents, parents, kids) jumping up from the sofa cheering, the youngest boy holding a golden trophy above his head, confetti in the air, a tablet glowing on the table, pure joy |

**Tips**
- If faces look odd, add *"natural friendly faces, modest traditional clothing"*.
- Keep the family the same across images by starting each prompt with *"the same family as before:"* in the same Nano Banana chat.
- If any image is missing, the video still works: that moment just shows the glow background.
