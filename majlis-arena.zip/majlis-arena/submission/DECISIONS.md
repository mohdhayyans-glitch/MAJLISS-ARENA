# Decisions

| Decision | Why |
|----------|-----|
| Concept D "World Cup of Families", renamed **Majlis Arena · Yallah Games!** | Team choice: merges the passport tour, AI commentator and family facts |
| Plain HTML/CSS/JS + small Express server, no build step, no database, no login | Fastest reliable stack in 3 hours, nothing to break during the demo |
| Gemini called **only from the server** (`server.js`), key in `.env` | API key never reaches the browser |
| Offline deck + strict JSON validation | The game must stay playable if the AI is slow, wrong or offline. Honest "OFFLINE DECK" badge |
| Host always decides Correct / Try Again; the AI never judges | Fair for families, and stops AI mistakes from costing points |
| "Deal a different card (no penalty)" button | Lets the host skip any AI card that seems wrong or unsuitable |
| Football = attack drives (3 correct in a row = goal) | Makes Football feel like football, not just a quiz |
| Half points after the hint (solo games) | Rewards first-try knowledge but keeps the game kind |
| Sudden death up to 3 rounds, then shared trophy | Required tie-break rule without endless games |
| Charades card hidden until the actor taps Reveal | Stops the guesser seeing the answer |
| Colors from haoqi.design + the team's glass mock-ups (violet/teal/lime) | Team request |
| 3D title: our own three.js scene (Rubik font + glass material), **not** haoqi.design's model or code | We studied the technique only. Their assets belong to them |
| One shared glass shader for all 3D glass objects + `compileAsync` | On Windows, each glass material variant froze the page for seconds |
| 3D icons: Microsoft Fluent Emoji 3D (MIT), stored locally | Matches the glossy 3D mock-ups, works offline, license allows reuse |
| Commentary uses pre-written lines | Instant feedback after every tap, with no extra AI cost or delay |
