# Status: Majlis Arena · Yallah Games!

## Working (tested, see TESTS.md)
- Long-scroll landing page (≈20 screens): 3D glass "Majlis Arena" title (three.js), line-up, 5 game deep-dives, how it works, teams, majlis values, family facts, AI, scoreboard, tie-breaks, FAQ, final call to action.
- All **five games playable end to end** on one shared engine: choose game → P1–P4 (Team A = P1+P2, Team B = P3+P4) → points / seconds / rounds / difficulty / tie-break → ready check → AI or offline card → host Correct / Try Again → round scores → sudden death or shared trophy → final results.
- Timer per card with pause, time's-up warning, and extra time on Try Again.
- Offline deck (12 cards per game, 10 for Story) used automatically if the AI fails; always labeled.
- Family facts (hometown, dish, sport) sent to the AI prompt.
- Family passport stamps (saved on this device).
- Mobile layout with the host buttons in thumb reach.

## Gemini (tested with the team's key)
- **Text works:** `gemini-3.5-flash` writes the cards for all five games and the Story Chest final story. It takes about 5–9 s per card.
- **Images don't work on this key:** the free tier allows 0 image requests. Every Gemini image model returned HTTP 429. The app shows the AI's image prompt (labeled) plus 3D icons instead. To get real pictures, the key needs billing turned on in Google AI Studio. No code change is needed.
- If Google is busy (HTTP 503), the server retries once, then uses the offline deck.
- AI facts can occasionally be wrong. The host sees the answer and can tap "Deal a different card".

## Not done / limitations
- AI images appear only in Market Mystery and the Story Chest front page (by design, since charades must stay secret).
- Commentary lines are pre-written (instant), not AI-generated.
- The text fonts (Space Grotesk, JetBrains Mono) load from Google Fonts. Offline, they fall back to system fonts. Rubik (display text) and the 3D font are served locally.
- Exiting mid-game loses that game's scores (a confirm dialog warns first).
- Test runs added passport stamps to this browser. Clear the site data to reset.
