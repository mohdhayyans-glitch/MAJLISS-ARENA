# Concept — Majlis Arena · Yallah Games!

## Core idea
A family game night held in a *majlis* (the gathering room where family and guests sit together).
The family goes on a "World Cup" tour of five games, hosted by an AI sports commentator. The family can
add a few facts about itself (hometown, a family dish, a favorite sport), and the AI weaves those into the clues.
Each finished game earns a stamp, and the night ends with a winner and a family "newspaper front page".

## The five games
| # | Game | Mode | What the AI makes |
|---|------|------|-------------------|
| 1 | ⚽ World Cup Match (Football, flagship) | Team A (P1+P2) vs Team B (P3+P4) | Football riddles; a correct answer moves the ball up the pitch, and a goal scores points; a commentary line after each result |
| 2 | 🧺 Market Mystery | Individual, P1–P4 take turns | A market scene (text + Gemini image) to guess the country from |
| 3 | 🎉 Festival Charades | Team | A festival card (+ image) to act out before the timer runs out |
| 4 | 💬 Grandma's Proverb | Individual | The start of a well-known world proverb to finish or explain |
| 5 | 📜 Story Chest Finale | Team | Teams add story lines, then the AI writes the family story + a newspaper image |

## Required flow (every game)
Choose game → players P1–P4 / teams → points, round time, tie-break, ready → AI content →
host taps **Correct** / **Try Again** → round scores → final results.

## AI integration
- Gemini, called only from our Node server (the API key never reaches the browser).
- If the AI fails or is slow, a curated offline deck is used, clearly marked with an "Offline deck" badge.
- If image generation fails, the game shows an emoji picture card and the labeled image prompt.
- Content rules: family-friendly, culturally respectful, suitable for ages 11–14.

## Visual identity
Colors copied from haoqi.design (team request): paper `#FBFAF4`, ink `#000`, lime `#C0FE04`,
dark lime `#607F02`, sky `#BFD9F2`, mist `#DCEBFA`, blue `#2F6FE8`. A glossy 3D "Majlis Arena"
title on the landing page, our own three.js build.

## Success criteria
- All five games are playable from setup to final results, with working scores, timer and tie-break.
- The AI content is used in real gameplay, and the game still works offline.
- It feels like one game night, not five separate mini-apps.
