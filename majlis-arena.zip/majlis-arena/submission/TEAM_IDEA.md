# Team Ideas — Majlis Arena

This file records only what our team actually said or chose. Nothing here was invented by the AI assistant.

## Brainstorm
- The team skipped the long brainstorm because time was short.
- On the first three concepts (A Passport Party, B Family Stadium Live, C Grandma's Story Chest), the team said they liked **"all of them"** and asked for more options.
- From the extra options, the team chose **Concept D: World Cup of Families**, which merges A + B + C.

## Team decisions
- **AI provider:** Google AI Studio. Gemini Flash for text and the Gemini image model for pictures (the team's choice).
- **App name:** the team picked "Family World Cup" first, then changed it to **Majlis Arena**, with **"Yallah Games!"**.
- **Colors:** the team asked us to copy the color palette of the website haoqi.design.
- **3D title:** the team asked for a 3D text design like the "hello" on haoqi.design, built with **three.js**.
- **Build order:** the team asked for the **landing page first**.
