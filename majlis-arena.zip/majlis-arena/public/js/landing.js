// Landing hero: glossy, "inflated" 3D "Majlis Arena" title in three.js.
// Our own scene — puffy bevelled text + glass-like physical material + room reflections.
// The canvas covers the whole hero; the title is framed inside #stage.
// Falls back to the flat CSS title when WebGL is missing or reduced motion is requested.
import * as THREE from 'three';
import { FontLoader } from 'three/addons/loaders/FontLoader.js';
import { TextGeometry } from 'three/addons/geometries/TextGeometry.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';

const hero = document.querySelector('.hero');
const stage = document.getElementById('stage');
const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

function webglAvailable() {
  try {
    const c = document.createElement('canvas');
    return Boolean(window.WebGL2RenderingContext && c.getContext('webgl2'));
  } catch {
    return false;
  }
}

if (hero && stage && webglAvailable() && !reduceMotion) {
  start().catch((err) => {
    console.warn('3D title unavailable, using flat title:', err);
    document.documentElement.classList.remove('is-3d');
  });
}

// Aurora backdrop (peach → aqua → periwinkle → violet), drawn at the hero's aspect ratio so it
// maps 1:1 onto the full-screen backdrop plane. Mirrors the CSS fallback in landing.css.
function paintBackdrop(canvas, aspect) {
  const W = 1024;
  const H = Math.max(256, Math.round(W / aspect));
  canvas.width = W; canvas.height = H;
  const ctx = canvas.getContext('2d');
  const g = ctx.createLinearGradient(0, H * 0.2, W, H * 0.8);
  g.addColorStop(0, '#F6DCCB');
  g.addColorStop(0.32, '#A8E6EF');
  g.addColorStop(0.62, '#9DB4F5');
  g.addColorStop(0.85, '#6B4FD0');
  g.addColorStop(1, '#3D2A9A');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, W, H);

  const blob = (x, y, r, color) => {
    const rg = ctx.createRadialGradient(x, y, 0, x, y, r);
    rg.addColorStop(0, color);
    rg.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = rg;
    ctx.fillRect(0, 0, W, H);
  };
  blob(0, H * 0.2, W * 0.45, 'rgba(249,215,195,0.9)');
  blob(W, H * 0.75, W * 0.5, 'rgba(61,42,154,0.85)');
  blob(W * 0.45, H * 0.45, W * 0.3, 'rgba(255,255,255,0.25)');

  // diagonal light streaks
  ctx.filter = 'blur(26px)';
  ctx.fillStyle = 'rgba(255,255,255,0.35)';
  for (const [x, w] of [[0.18, 40], [0.5, 22], [0.78, 60]]) {
    ctx.save();
    ctx.translate(W * x, H / 2);
    ctx.rotate(-0.55);
    ctx.fillRect(-w / 2, -H * 1.5, w, H * 3);
    ctx.restore();
  }
  ctx.filter = 'none';
  // sparkles
  for (let i = 0; i < 90; i++) {
    const x = Math.random() * W, y = Math.random() * H, r = Math.random() * 1.6 + 0.3;
    ctx.fillStyle = `rgba(255,255,255,${0.3 + Math.random() * 0.6})`;
    ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.fill();
  }
}

async function start() {
  const font = await new FontLoader().loadAsync('/fonts/rubik-black.typeface.json');

  const renderer = new THREE.WebGLRenderer({ antialias: true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.05;
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.domElement.className = 'hero-canvas';
  renderer.domElement.setAttribute('aria-hidden', 'true');
  hero.prepend(renderer.domElement);

  const scene = new THREE.Scene();
  const pmrem = new THREE.PMREMGenerator(renderer);
  scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;

  const camera = new THREE.PerspectiveCamera(32, 1, 0.1, 100);
  camera.position.set(0, 0, 14);

  // Backdrop plane fills the view; sized in resize(). Not tone mapped so it matches the CSS exactly.
  const BACKDROP_Z = -6;
  const backdropCanvas = document.createElement('canvas');
  paintBackdrop(backdropCanvas, hero.clientWidth / Math.max(hero.clientHeight, 1));
  const backdropTex = new THREE.CanvasTexture(backdropCanvas);
  backdropTex.colorSpace = THREE.SRGBColorSpace;
  let paintedAspect = hero.clientWidth / Math.max(hero.clientHeight, 1);
  const backdrop = new THREE.Mesh(
    new THREE.PlaneGeometry(1, 1),
    new THREE.MeshBasicMaterial({ map: backdropTex, toneMapped: false })
  );
  backdrop.position.z = BACKDROP_Z;
  scene.add(backdrop);

  // --- the puffy title ---
  const geo = new TextGeometry('Majlis\nArena', {
    font,
    size: 1.25,
    depth: 0.32,
    curveSegments: 8,
    bevelEnabled: true,
    bevelThickness: 0.26,
    bevelSize: 0.075,
    bevelSegments: 8
  });
  geo.center();
  geo.computeVertexNormals();

  // Violet glass with an iridescent sheen. The panel and crystal use the same feature set
  // (transmission + clearcoat + iridescence) so all three share ONE shader program —
  // Windows/ANGLE compiles each physical-material variant slowly.
  const glass = new THREE.MeshPhysicalMaterial({
    color: 0xc7b0ff,
    metalness: 0,
    roughness: 0.1,
    transmission: 0.78,
    thickness: 1.3,
    ior: 1.45,
    attenuationColor: new THREE.Color('#6E2FE0'),
    attenuationDistance: 0.55,
    clearcoat: 1,
    clearcoatRoughness: 0.05,
    iridescence: 0.9,
    iridescenceIOR: 1.35,
    iridescenceThicknessRange: [180, 620],
    envMapIntensity: 1.5
  });

  const title = new THREE.Mesh(geo, glass);
  const titleGroup = new THREE.Group();
  titleGroup.add(title);
  scene.add(titleGroup);

  geo.computeBoundingBox();
  const bb = geo.boundingBox;
  const textW = bb.max.x - bb.min.x;
  const textH = bb.max.y - bb.min.y;

  // frosted glass panel behind the title
  const panel = new THREE.Mesh(
    new RoundedBoxGeometry(textW + 2.2, textH + 1.3, 0.12, 6, 0.35),
    new THREE.MeshPhysicalMaterial({
      color: 0xffffff, roughness: 0.38, transmission: 1, thickness: 0.4, ior: 1.3,
      clearcoat: 1, clearcoatRoughness: 0.2, iridescence: 0.15, envMapIntensity: 0.9
    })
  );
  panel.position.set(0.25, -0.05, -1.1);
  panel.rotation.y = -0.06;
  titleGroup.add(panel);

  // --- little game-night props floating around the title ---
  const props = new THREE.Group();
  titleGroup.add(props);

  // props: cheap standard materials (one shared program)
  const lime = new THREE.MeshStandardMaterial({ color: '#C0FE04', roughness: 0.25 });
  const ink = new THREE.MeshStandardMaterial({ color: '#1a1622', roughness: 0.3, metalness: 0.6 });
  const blue = new THREE.MeshStandardMaterial({ color: '#8f6bff', roughness: 0.2 });
  const crystal = new THREE.MeshPhysicalMaterial({
    color: 0xffffff, roughness: 0.02, transmission: 1, thickness: 0.8, ior: 1.6,
    clearcoat: 1, iridescence: 1, iridescenceThicknessRange: [200, 700], envMapIntensity: 1.6
  });

  const px = textW / 2 + 0.9;
  const py = textH / 2 - 0.35;

  // football: lime ball with dark seams
  const ball = new THREE.Group();
  ball.add(new THREE.Mesh(new THREE.IcosahedronGeometry(0.42, 1), lime));
  ball.add(new THREE.Mesh(
    new THREE.IcosahedronGeometry(0.432, 0),
    new THREE.MeshBasicMaterial({ color: '#111', wireframe: true })
  ));
  ball.position.set(px, py, 0.6);
  props.add(ball);

  // dice: rounded blue cube
  const dice = new THREE.Mesh(new THREE.BoxGeometry(0.75, 0.75, 0.75, 4, 4, 4), blue);
  roundBox(dice.geometry, 0.12);
  dice.scale.setScalar(0.75);
  dice.position.set(-px, -py, 0.4);
  props.add(dice);

  // ring: black torus
  const ring = new THREE.Mesh(new THREE.TorusGeometry(0.32, 0.11, 24, 64), ink);
  ring.position.set(-px + 0.2, py, -0.3);
  props.add(ring);

  // star: crystal d20 (like a game die made of glass)
  const star = new THREE.Mesh(new THREE.IcosahedronGeometry(0.42, 0), crystal);
  star.position.set(px - 0.2, -py, -0.2);
  props.add(star);

  const key = new THREE.DirectionalLight('#ffffff', 1.6);
  key.position.set(3, 5, 6);
  scene.add(key);
  scene.add(new THREE.AmbientLight('#dcebfa', 0.4));

  // --- framing: canvas = whole hero, title fits inside #stage ---
  let baseY = 0;
  function resize() {
    const heroW = hero.clientWidth;
    const heroH = hero.clientHeight;
    const sr = stage.getBoundingClientRect();
    const hr = hero.getBoundingClientRect();
    const stageW = Math.max(sr.width, 1);
    const stageH = Math.max(sr.height, 1);

    renderer.setSize(heroW, heroH, false);
    camera.aspect = heroW / heroH;

    const showProps = stageW / stageH > 1.6;
    props.visible = showProps;
    const fitW = (showProps ? textW + 3.2 : textW + 0.6);
    const fitH = textH + 0.8;

    const tan = Math.tan(THREE.MathUtils.degToRad(camera.fov) / 2);
    const needH = Math.max(fitH * (heroH / stageH), (fitW * (heroW / stageW)) / camera.aspect);
    camera.position.z = needH / (2 * tan);
    camera.updateProjectionMatrix();

    const pxToWorld = (2 * camera.position.z * tan) / heroH;
    const stageCenter = sr.top - hr.top + stageH / 2;
    baseY = -(stageCenter - heroH / 2) * pxToWorld;

    const dist = camera.position.z - BACKDROP_Z;
    const bh = 2 * dist * tan;
    backdrop.scale.set(bh * camera.aspect, bh, 1);
    if (Math.abs(camera.aspect - paintedAspect) / paintedAspect > 0.15) {
      paintedAspect = camera.aspect;
      paintBackdrop(backdropCanvas, paintedAspect);
      backdropTex.needsUpdate = true;
    }
  }
  new ResizeObserver(resize).observe(hero);
  resize();

  // --- interaction: tilt toward pointer, turn a little on scroll ---
  const target = { x: 0, y: 0 };
  window.addEventListener('pointermove', (e) => {
    target.x = (e.clientX / window.innerWidth) * 2 - 1;
    target.y = (e.clientY / window.innerHeight) * 2 - 1;
  }, { passive: true });

  let visible = true;
  new IntersectionObserver(([entry]) => { visible = entry.isIntersecting; }).observe(hero);

  // Compile shaders off the main thread where supported; the flat title stays visible meanwhile.
  await renderer.compileAsync(scene, camera);
  document.documentElement.classList.add('is-3d');

  const t0 = performance.now();
  let last = t0;
  let intro = 0;

  renderer.setAnimationLoop((now) => {
    if (!visible || document.hidden) { last = now; return; }
    const t = (now - t0) / 1000;
    const dt = Math.min((now - last) / 1000, 0.05);
    last = now;

    // entrance: pop in with a small overshoot
    intro = Math.min(1, intro + dt * 1.4);
    titleGroup.scale.setScalar(0.6 + 0.4 * easeOutBack(intro));

    const scroll = Math.min(window.scrollY / window.innerHeight, 1);
    const ry = target.x * 0.35 + Math.sin(t * 0.6) * 0.06 + scroll * 0.9;
    const rx = target.y * 0.22 + Math.sin(t * 0.8) * 0.03 - scroll * 0.25;
    titleGroup.rotation.y += (ry - titleGroup.rotation.y) * 0.06;
    titleGroup.rotation.x += (rx - titleGroup.rotation.x) * 0.06;
    titleGroup.position.y = baseY + Math.sin(t * 1.1) * 0.08;

    ball.rotation.x = t * 0.9; ball.rotation.y = t * 0.6;
    ball.position.y = py + Math.sin(t * 1.4) * 0.15;
    dice.rotation.x = t * 0.5; dice.rotation.z = t * 0.35;
    dice.position.y = -py + Math.sin(t * 1.2 + 1) * 0.14;
    ring.rotation.y = t * 0.8; ring.rotation.x = 0.6 + Math.sin(t) * 0.2;
    star.rotation.y = t * 0.7; star.rotation.x = t * 0.4;
    star.position.y = -py + Math.sin(t * 1.6 + 2) * 0.12;

    renderer.render(scene, camera);
  });
}

function easeOutBack(x) {
  const c1 = 1.70158, c3 = c1 + 1;
  return 1 + c3 * Math.pow(x - 1, 3) + c1 * Math.pow(x - 1, 2);
}

// Pushes box vertices outward toward a sphere near the corners → rounded dice.
function roundBox(geometry, radius) {
  const pos = geometry.attributes.position;
  const v = new THREE.Vector3();
  const c = new THREE.Vector3();
  const inner = 0.375 - radius;
  for (let i = 0; i < pos.count; i++) {
    v.fromBufferAttribute(pos, i);
    c.set(
      THREE.MathUtils.clamp(v.x, -inner, inner),
      THREE.MathUtils.clamp(v.y, -inner, inner),
      THREE.MathUtils.clamp(v.z, -inner, inner)
    );
    v.sub(c);
    if (v.lengthSq() > 0) v.setLength(radius);
    pos.setXYZ(i, c.x + v.x, c.y + v.y, c.z + v.z);
  }
  geometry.computeVertexNormals();
}
