# Tests: Majlis Arena

Run on 29 Oct 2026, locally (Node 26, Windows 11, built-in browser). Game loops were tested with the offline deck. Real Gemini was then tested with the team's key.
Marked: ✅ tested and passed · 🟡 simulated (fake key, not the real AI) · ⬜ not tested yet.

## Full game loops (driven in the browser, offline deck)
| # | Test | Result |
|---|------|--------|
| 1 | World Cup Match: Team A answers 3 correct → GOAL, +3 shown on the scoreboard | ✅ |
| 2 | World Cup Match: Try Again shows the hint; a second miss = "Saved!" and the turn passes to Team B | ✅ |
| 3 | Round scores screen shows per-round points (R1/R2) and totals | ✅ |
| 4 | Football 3–3 tie → Sudden death 1/3 → Team A scores, B misses → "Decided in sudden death!" | ✅ |
| 5 | Market Mystery (solo, 4 players): full points first try, **half points after the hint** (2 → 1), miss = 0 | ✅ |
| 6 | Market Mystery: two players tied → sudden death between **only those two** (other two greyed out) | ✅ |
| 7 | Festival Charades: Correct/Try Again **locked until the actor taps Reveal**; timer waits for the reveal | ✅ |
| 8 | Festival Charades: actor and guesser **swap** in round 2 (Mama/Baba → Baba/Mama) | ✅ |
| 9 | Grandma's Proverb with "Share the trophy": all 0 → shared trophy for all four | ✅ |
| 10 | Story Chest: typed story lines saved (3 lines), front page generated (offline template) | ✅ |
| 11 | Story Chest: HTML typed into a story line is stripped (no injection) | ✅ |
| 12 | Game switching via "Choose another game" (football → market → festival → proverb → story in one session) | ✅ |
| 13 | Passport stamp saved after each finished game | ✅ |

## Validation
| Test | Result |
|------|--------|
| Empty names → "Please enter a name for P1, P2, P3, P4." | ✅ |
| Duplicate names (Mama / mama) → blocked with message | ✅ |
| Points 0 and seconds 5 → both errors shown, form blocked | ✅ |
| Kick-off button disabled until every team taps Ready | ✅ |

## AI and failure handling
| Test | Result |
|------|--------|
| No key → status chip "OFFLINE DECK MODE", all cards labeled OFFLINE DECK | ✅ |
| Fake key → Google returns HTTP 400 → all 5 games fall back to the offline deck | 🟡 (real Google error, fake key) |
| Fake key → image request fails cleanly (`ok:false`) → UI shows the 3D icon card + labeled image prompt | 🟡 |
| Unknown game id sent to `/api/card` → HTTP 400 | ✅ |
| **Real Gemini text cards (`gemini-3.5-flash`), all 5 games** | ✅ source=ai, 5–9 s per card, family facts (Muscat, machboos) used in the cards |
| **Real Gemini final story + headline (Story Chest)** | ✅ source=ai, uses the teams' typed lines |
| Gemini "busy" (HTTP 503) on first try | ✅ seen live; server now retries once, then uses the offline deck |
| **Real Gemini image generation** | ❌ not available: the team's free-tier key has an image quota of 0 (HTTP 429 on `gemini-2.5-flash-image`, `gemini-3.1-flash-image`, `gemini-3.1-flash-lite-image`, `gemini-nano-banana-2.1`). The app shows the labeled image prompt + 3D icons, and the status chip switches to "GEMINI ON · TEXT" |

## Layout
| Test | Result |
|------|--------|
| Landing page renders; 3D title compiles in ~4 s without freezing the page (shader compile is async) | ✅ |
| Landing at 375 px wide: no sideways scrolling | ✅ |
| Game screen at 375 px: Correct / Try Again pinned to the bottom of the screen | ✅ |
| No console errors on landing or play pages | ✅ |
| Flat-title fallback when WebGL is off | ⬜ not tested (code path exists) |
