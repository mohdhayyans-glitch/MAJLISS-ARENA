// Offline card decks: used when Gemini is not configured, slow, or returns bad data.
// Every card is marked source:"offline" by the server so the UI can show the badge.
// Content rule: well-known, respectful, family-friendly facts only.

export const decks = {
  football: [
    { clue: 'I am the only player who may catch the ball with my hands, but only inside my own penalty box. Who am I?', answer: 'The goalkeeper', hint: 'I wear gloves.', fact: 'Goalkeepers often wear a different colour shirt so the referee can spot them.' },
    { clue: 'The men\'s FIFA World Cup is played once every how many years?', answer: 'Every 4 years', hint: 'Same as the Olympics.', fact: 'The first World Cup was held in Uruguay in 1930.' },
    { clue: 'In 2022 this country hosted the first World Cup in the Arab world. Name it.', answer: 'Qatar', hint: 'Its capital is Doha.', fact: 'It was also the first World Cup held in November and December.' },
    { clue: 'One player scores three goals in a single match. What is that called?', answer: 'A hat-trick', hint: 'It is something you might wear on your head… plus a trick.', fact: 'The name comes from cricket, where a bowler once won a hat.' },
    { clue: 'Which colour card does the referee show to send a player off the pitch?', answer: 'Red', hint: 'The colour of a stop sign.', fact: 'Yellow and red cards were first used at the 1970 World Cup.' },
    { clue: 'How many players does each team have on the pitch at kick-off, including the goalkeeper?', answer: '11', hint: 'Two teams together make 22.', fact: 'If a team drops below 7 players, the match is stopped.' },
    { clue: 'In 2022 Argentina won the World Cup. Which captain, wearing number 10, lifted the trophy?', answer: 'Lionel Messi', hint: 'His first name starts with L.', fact: 'He was also named best player of that tournament.' },
    { clue: 'At the 2022 World Cup, Saudi Arabia beat this future champion 2–1 in one of the biggest surprises ever. Which team?', answer: 'Argentina', hint: 'They play in light-blue and white stripes.', fact: 'Saudi Arabia celebrated the win with a national holiday.' },
    { clue: 'In 2022 Morocco became the first African and Arab team to reach which stage of the World Cup?', answer: 'The semi-finals', hint: 'One step before the final.', fact: 'Morocco\'s team is nicknamed the Atlas Lions.' },
    { clue: 'You kick the ball into your own team\'s net by mistake. What is that called?', answer: 'An own goal', hint: 'It counts for the other team.', fact: 'Even top professionals score them, usually by accident while defending.' },
    { clue: 'Which country has won the men\'s World Cup the most times: five?', answer: 'Brazil', hint: 'Famous for yellow shirts and samba.', fact: 'Brazil has played in every single men\'s World Cup.' },
    { clue: 'The ball goes over the goal line, last touched by a defender. Where is the kick taken from?', answer: 'The corner (a corner kick)', hint: 'Look for the little flag.', fact: 'You can score directly from a corner. It is called an olimpico.' }
  ],

  market: [
    { clue: 'Pointed leather slippers in every colour hang above the stalls. Cone-shaped clay pots steam with stew, and sellers pour mint tea from high up so it foams.', answer: 'Morocco', hint: 'The clay pots are called tagines.', fact: 'Marrakech\'s big square, Jemaa el-Fnaa, fills with food stalls at night.', imagePrompt: 'a lively souk in Marrakech with colourful leather slippers, tagine pots and mint tea' },
    { clue: 'Boats loaded with mangoes, coconuts and noodle soup float along a canal. Sellers in wide straw hats paddle their shops right to you.', answer: 'Thailand', hint: 'Its capital is Bangkok.', fact: 'Floating markets began because rivers were the main roads.' },
    { clue: 'Mountains of red, yellow and orange spice powders, stacks of bangles, and a tea seller making sweet milky chai with cardamom.', answer: 'India', hint: 'Home of the Taj Mahal.', fact: 'India grows more spices than any other country.', imagePrompt: 'a colourful Indian spice market with piles of spice powder, bangles and a chai stall' },
    { clue: 'Bright paper piñatas swing above stalls of fresh corn tortillas, chillies and orange marigold flowers.', answer: 'Mexico', hint: 'Tacos come from here.', fact: 'Corn has been grown in this country for about 9,000 years.', imagePrompt: 'a cheerful Mexican market with piñatas, tortillas, chillies and marigold flowers' },
    { clue: 'Under a huge painted roof, glowing mosaic lamps hang everywhere, and trays of sugar-dusted sweets in rose and pistachio flavours wait for you.', answer: 'Turkey (Türkiye)', hint: 'Istanbul is its biggest city.', fact: 'Istanbul\'s Grand Bazaar has more than 4,000 shops.', imagePrompt: 'a grand covered bazaar with glowing mosaic lamps and trays of Turkish delight' },
    { clue: 'The air smells of frankincense. Sellers offer silver daggers called khanjars, and dhow boats rock in the harbour beside the souq.', answer: 'Oman', hint: 'Its capital is Muscat.', fact: 'Frankincense has been traded from this land for thousands of years.', imagePrompt: 'a harbour souq in Muscat with frankincense, silver crafts and wooden dhow boats' },
    { clue: 'Stalls of fresh pasta, giant wheels of cheese and olives, and a scooter zipping past an old stone fountain.', answer: 'Italy', hint: 'The country is shaped like a boot.', fact: 'There are more than 300 shapes of pasta.', imagePrompt: 'an open-air Italian market with fresh pasta, cheese wheels and olives near a stone fountain' },
    { clue: 'Huge piles of dates in dozens of types, the smell of oud and cardamom coffee, and sellers in white thobes calling out prices.', answer: 'Saudi Arabia', hint: 'Riyadh is its capital.', fact: 'This country grows more than 300 kinds of dates.', imagePrompt: 'a traditional date market with piles of many kinds of dates and coffee pots' },
    { clue: 'Soft alpaca-wool ponchos and hats in rainbow patterns, purple corn drinks, and snowy mountains behind the market.', answer: 'Peru', hint: 'Machu Picchu is here.', fact: 'Peru has more than 3,000 kinds of potato.', imagePrompt: 'a mountain market with colourful alpaca wool ponchos and snowy Andes peaks' },
    { clue: 'Bright beaded necklaces and bracelets in red, blue and white, carved wooden animals, and the plains where lions and giraffes roam nearby.', answer: 'Kenya', hint: 'Its capital is Nairobi.', fact: 'Kenyan runners have won many Olympic long-distance medals.', imagePrompt: 'an outdoor craft market with colourful beaded jewellery and carved wooden animals' },
    { clue: 'Tiny wooden boxes of sushi, glowing paper lanterns, and a stall selling fish-shaped pancakes filled with sweet red bean.', answer: 'Japan', hint: 'Tokyo is its capital.', fact: 'The fish-shaped cakes are called taiyaki.', imagePrompt: 'a lantern-lit Japanese street market with sushi and fish-shaped taiyaki cakes' },
    { clue: 'Papyrus paintings, little pyramid statues, and copper lanterns in a maze of old alleys near a thousand-year-old mosque.', answer: 'Egypt', hint: 'The river Nile flows through it.', fact: 'Cairo\'s Khan el-Khalili market dates back to the 1300s.', imagePrompt: 'a winding old Cairo bazaar with papyrus art, copper lanterns and small pyramid souvenirs' }
  ],

  festival: [
    { clue: 'Eid al-Fitr', answer: 'Eid al-Fitr', hint: 'Act: wearing new clothes, hugging family, giving gifts, eating sweets.', fact: 'It marks the end of Ramadan. Many families give children money called Eidiya.' },
    { clue: 'Diwali (India)', answer: 'Diwali', hint: 'Act: lighting small lamps, setting off fireworks, sharing sweets.', fact: 'Diwali is often called the Festival of Lights.' },
    { clue: 'Lunar New Year (China and East Asia)', answer: 'Lunar New Year', hint: 'Act: a dragon dance, handing out red envelopes, fireworks.', fact: 'Each year is linked to one of 12 animals.' },
    { clue: 'Holi (India)', answer: 'Holi', hint: 'Act: throwing coloured powder at friends and laughing.', fact: 'Holi celebrates the arrival of spring.' },
    { clue: 'Songkran (Thailand)', answer: 'Songkran', hint: 'Act: splashing water with buckets and water guns.', fact: 'It is the Thai New Year, held in the hottest month.' },
    { clue: 'Carnival (Brazil)', answer: 'Carnival', hint: 'Act: samba dancing in a parade with a huge costume.', fact: 'Rio\'s Carnival parade has thousands of dancers.' },
    { clue: 'Hanami (Japan)', answer: 'Hanami', hint: 'Act: having a picnic and looking up at falling cherry blossoms.', fact: 'Hanami means flower viewing.' },
    { clue: 'Mid-Autumn Festival (China)', answer: 'Mid-Autumn Festival', hint: 'Act: carrying a lantern, eating a round mooncake, gazing at the full moon.', fact: 'Families gather to admire the brightest moon of the year.' },
    { clue: 'Nowruz (Iran and Central Asia)', answer: 'Nowruz', hint: 'Act: spring cleaning, planting green sprouts, visiting relatives.', fact: 'Nowruz means new day and starts on the first day of spring.' },
    { clue: 'La Tomatina (Spain)', answer: 'La Tomatina', hint: 'Act: a friendly tomato fight, throwing and dodging.', fact: 'The tomatoes used are overripe ones that cannot be sold.' },
    { clue: 'UAE National Day', answer: 'UAE National Day', hint: 'Act: waving a flag, doing a traditional stick dance, watching fireworks.', fact: 'It is celebrated on 2 December, the day the UAE was founded in 1971.' },
    { clue: 'Thanksgiving (USA and Canada)', answer: 'Thanksgiving', hint: 'Act: carving a big turkey and saying thank you at a family dinner.', fact: 'Canada celebrates it in October, the USA in November.' }
  ],

  proverb: [
    { clue: 'A journey of a thousand miles…', answer: '…begins with a single step.', hint: 'Every big thing starts small.', fact: 'A Chinese saying linked to the thinker Laozi.' },
    { clue: 'Fall seven times…', answer: '…stand up eight.', hint: 'Count one more than seven.', fact: 'A Japanese proverb about never giving up.' },
    { clue: 'If you want to go fast, go alone…', answer: '…if you want to go far, go together.', hint: 'Think: teamwork.', fact: 'Often shared as an African proverb.' },
    { clue: 'Patience is the key to…', answer: '…relief.', hint: 'In Arabic: "as-sabr miftah al-faraj."', fact: 'A well-known Arabic proverb about waiting calmly through hard times.' },
    { clue: 'Trust in God…', answer: '…but tie your camel.', hint: 'Do your part as well.', fact: 'A famous Arab saying: have faith, and also be responsible.' },
    { clue: 'Rome wasn\'t built…', answer: '…in a day.', hint: 'How long does a big city take?', fact: 'Great things take time. This saying is centuries old.' },
    { clue: 'Many hands…', answer: '…make light work.', hint: 'Sharing a job makes it easier.', fact: 'An old English proverb about teamwork.' },
    { clue: 'Actions speak louder…', answer: '…than words.', hint: 'Doing vs. saying.', fact: 'What you do shows more than what you promise.' },
    { clue: 'The early bird…', answer: '…catches the worm.', hint: 'Breakfast for birds.', fact: 'Getting started early gives you an advantage.' },
    { clue: 'Don\'t count your chickens…', answer: '…before they hatch.', hint: 'Eggs first!', fact: 'Don\'t celebrate before something actually happens.' },
    { clue: 'Every cloud…', answer: '…has a silver lining.', hint: 'Something shiny around the edge.', fact: 'Even bad moments can bring something good.' },
    { clue: 'A friend in need…', answer: '…is a friend indeed.', hint: 'Rhymes with need.', fact: 'A friend who helps when you need it is a true friend.' }
  ],

  story: [
    { clue: 'Setting: a windy beach at sunset. Use all three words: falcon, grandma, football.', answer: 'Any story line that uses all 3 words', hint: 'Start with "One evening…"', fact: 'Falconry is a heritage tradition recognised by UNESCO.' },
    { clue: 'Setting: a busy night market. Use: lantern, cousin, secret recipe.', answer: 'Any story line that uses all 3 words', hint: 'Who is keeping the secret?', fact: 'Night markets are popular across Asia and the Middle East.' },
    { clue: 'Setting: a desert camp under the stars. Use: camel, map, laughter.', answer: 'Any story line that uses all 3 words', hint: 'What does the map lead to?', fact: 'People once navigated the desert using the stars.' },
    { clue: 'Setting: the final minute of a big match. Use: whistle, little brother, rain.', answer: 'Any story line that uses all 3 words', hint: 'Who blows the whistle?', fact: 'Some of football\'s most famous goals came in the final minute.' },
    { clue: 'Setting: grandpa\'s old majlis. Use: coffee pot, photo album, surprise.', answer: 'Any story line that uses all 3 words', hint: 'What is in the album?', fact: 'Arabic coffee and the majlis are both on UNESCO\'s heritage lists.' },
    { clue: 'Setting: a fishing boat at dawn. Use: pearl, song, storm.', answer: 'Any story line that uses all 3 words', hint: 'Pearl divers used to sing on the boats.', fact: 'Pearl diving was once a major way of life in the Gulf.' },
    { clue: 'Setting: a mountain village festival. Use: drum, kite, lost shoe.', answer: 'Any story line that uses all 3 words', hint: 'Where did the shoe go?', fact: 'Kite festivals are held in many countries, from India to Afghanistan.' },
    { clue: 'Setting: a school sports day. Use: trophy, spaghetti, robot.', answer: 'Any story line that uses all 3 words', hint: 'Why is there spaghetti?', fact: 'The first robots were built to help in factories.' },
    { clue: 'Setting: a garden at Eid. Use: balloon, sweets, giant cat.', answer: 'Any story line that uses all 3 words', hint: 'How big is the cat?', fact: 'Many families share sweets with neighbours at Eid.' },
    { clue: 'Setting: an airport on the way to a trip. Use: passport, parrot, dance.', answer: 'Any story line that uses all 3 words', hint: 'Does the parrot have a ticket?', fact: 'Some parrots can learn more than 100 words.' }
  ]
};

export const commentary = {
  correct: [
    '{who} reads it perfectly! What a touch!',
    'Brilliant from {who}! The majlis is on its feet!',
    '{who} makes it look easy. Pure class!',
    'Yallah! {who} nails it!'
  ],
  goal: [
    'GOOOAL! {who} finds the back of the net!',
    'It\'s in! {who} scores and the whole family goes wild!',
    'What a strike! {who} celebrates a beautiful goal!'
  ],
  miss: [
    'Saved! The keeper denies {who} this time.',
    'So close for {who}! Next time, inshallah.',
    'Just wide! {who} will be back.'
  ],
  retry: [
    'A second chance for {who}. Here\'s a hint…',
    '{who} takes a deep breath. Try again!'
  ]
};
