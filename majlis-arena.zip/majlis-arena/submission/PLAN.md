# Build Plan — Majlis Arena

## Stack
- `server.js`: Node + Express. Serves `public/` and the AI endpoints (`/api/generate`, `/api/image`, `/api/commentary`).
- `public/`: plain HTML/CSS/JS, no build step. Landing page uses three.js (installed with npm, served locally).
- `.env`: `GEMINI_API_KEY`, `GEMINI_TEXT_MODEL`, `GEMINI_IMAGE_MODEL`. Never committed; never sent to the browser.
- `fallback/*.json`: offline content deck per game.

## Stages
1. ✅ Concept chosen, submission docs started.
2. Landing page with 3D "Majlis Arena" hero → show to the team.
3. Server + Gemini test call (check that the model names work) + offline fallback.
4. Shared game engine + World Cup Match playable end to end.
5. The other four games on the same engine.
6. Polish: results screen, instructions, images.
7. Testing + judge review (max 3 reviews, 30 min), STATUS / DECISIONS / TESTS docs, demo script.

## Risks
| Risk | Plan |
|------|------|
| Gemini key or model name not working | Test call first; the offline deck keeps every game playable |
| Image generation is slow | Generate during the round; emoji card fallback |
| Cultural mistakes in AI content | Strict prompt rules; offline deck reviewed by the team |
| Running out of time | World Cup Match first and polished; the other games simple but complete |
| 3D title fails on a weak laptop | Automatic flat-title fallback |
